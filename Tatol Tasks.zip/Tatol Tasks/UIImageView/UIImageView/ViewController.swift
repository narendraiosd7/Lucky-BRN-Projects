//
//  ViewController.swift
//  UIImageView
//
//  Created by Vadde Narendra on 11/28/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController
{

    @IBOutlet weak var stackView: UIStackView!
    
    var userData : [[String:Any]]!
    var buttonsArray:[UIButton] = []
    var labelsArray:[UILabel] = []
    var audioURLs:[[String]] = [[]]
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    
    
    func creatingComponents()
    {
        var j = 0
        let moviesData = GettingMoviesData.shared.gettingMoviesDetails()
        
        for (x,y) in zip(buttonsArray,labelsArray)
        {
            x.removeFromSuperview()
            y.removeFromSuperview()
        }
        
        buttonsArray = [UIButton]()
        labelsArray = [UILabel]()
        
        GettingMoviesData.shared.movieBtnTags = 0
        GettingMoviesData.shared.moviesStory = [String]()
        GettingMoviesData.shared.MoviesTitle = [String]()
        GettingMoviesData.shared.actorsNames = [[String]]()
        GettingMoviesData.shared.directorName = [String]()
        GettingMoviesData.shared.moviePosterImage = [UIImage]()
        
        for i in moviesData
        {
            let posterImage = (i["posters"] as! [String])[0]
            let urlString = posterImage.replacingOccurrences(of: " ", with: "%20")
            let posterURL = URL(string: "https://www.brninfotech.com/tws/\(urlString)")
            let posterDataTask = URLSession.shared.dataTask(with: posterURL!)
            {
                (posterData, conDetails, err) in
                
                DispatchQueue.main.async
                {
                    let moviePosterBtn = UIButton()
                    self.buttonsArray.append(moviePosterBtn)
                    self.stackView.addArrangedSubview(moviePosterBtn)
                    
                    moviePosterBtn.setImage(UIImage(data: posterData!), for: UIControl.State.normal)
                    moviePosterBtn.backgroundColor = UIColor.black
                    moviePosterBtn.translatesAutoresizingMaskIntoConstraints = false
                    moviePosterBtn.heightAnchor.constraint(equalToConstant: 300).isActive = true
                    //                button.widthAnchor.constraint(equalToConstant: 300).isActive = true
                    moviePosterBtn.imageView?.contentMode = .scaleAspectFit
                    
                    moviePosterBtn.addTarget(self, action: #selector(self.movieDetails(_:)), for: UIControl.Event.touchUpInside)
                    
                    moviePosterBtn.tag = j
                    
                    j += 1
                    
                    let movieTitle = i["title"] as! String
                    let movieTitleLbl = UILabel()
                    movieTitleLbl.text = movieTitle
                    movieTitleLbl.font = UIFont.boldSystemFont(ofSize: 20)
                    movieTitleLbl.textColor = UIColor.black
                    movieTitleLbl.textAlignment = .center
                    self.labelsArray.append(movieTitleLbl)
                    self.stackView.addArrangedSubview(movieTitleLbl)
                    
                    GettingMoviesData.shared.moviePosterImage.append(UIImage(data: posterData!)!)
                    GettingMoviesData.shared.directorName.append(i["director"] as! String)
                    GettingMoviesData.shared.MoviesTitle.append(i["title"] as! String)
                    GettingMoviesData.shared.moviesStory.append(i["story"] as? String ?? "Story not Available")
                
                    let actorsName = i["actors"] as! [String]
                    GettingMoviesData.shared.actorsNames.append(actorsName)
                    
                    let video = (i["trailers"] as! [String])[0]
                    let videoURL = video.replacingOccurrences(of: " ", with: "%20")
                    let videoAVPlayer = AVPlayerViewController()
                    videoAVPlayer.player = AVPlayer(url: URL(string: "https://www.brninfotech.com/tws/\(videoURL)")!)
                    GettingMoviesData.shared.movieTrailer.append(videoAVPlayer)
                    
                    let audiosURL = i["songs"] as! [String]
                    self.audioURLs.append(audiosURL)
                    
//                    let allAudioFiles = i["songs"] as! [String]
//
//                    var n = 0
//
//                    if(allAudioFiles.count > 0)
//                    {
//                        for m in 0...allAudioFiles.count - 1
//                        {
//                            let audioSongBtn = UIButton()
//                            audioSongBtn.tag = n
//                            n += 1
//                            print(n)
//                            audioSongBtn.setTitle(allAudioFiles[m], for: UIControl.State.normal)
//                            audioSongBtn.addTarget(self, action: #selector(self.audioSongs), for: UIControl.Event.touchUpInside)
//                        }
//                    }
                    
                    
                    
                    
                    
                }
            }
            posterDataTask.resume()
        }
    }
  
    @IBAction func menuBtnTapped(_ sender: UIButton)
    {
        creatingComponents()
    }
    
    
    
    
    func fetchAudio(urlInString:String) -> AVPlayer
    {
        let url = URL(string: urlInString)!

        return AVPlayer(url: url)
    }
    
    
    
    
    @objc func movieDetails(_ sender: UIButton)
    {
        
        GettingMoviesData.shared.movieBtnTags = sender.tag
     
//        print("***********************************\(audioURLs)******************************")
        
        
        print("SEnder",sender.tag)
        
        for x in audioURLs[sender.tag]
        {
            let urlInString = ("https://www.brninfotech.com/tws/" + x).replacingOccurrences(of: " ", with: "%20")
            
            GettingMoviesData.shared.audioSongsPaths.append(fetchAudio(urlInString: urlInString))
        }
        
        print("Audio",GettingMoviesData.shared.audioSongsPaths.count)
        
        let movieDetailsVC = storyboard?.instantiateViewController(withIdentifier: "moviesDetails") as! MoviesDetails
        
        present(movieDetailsVC, animated: true, completion: nil)
    }
    
    var audioPlayer = AVPlayerViewController()
    
//    @objc func audioSongs()
//    {
//        let moviesData = GettingMoviesData.shared.gettingMoviesDetails()
//        
//        for i in moviesData
//        {
//            let audioPaths = (i["songs"] as! [String])[0]
//            let audioURL = audioPaths.replacingOccurrences(of: " ", with: "%20")
//            let url = URL(string: "https://www.brninfotech.com/tws/\(audioURL)")
//            audioPlayer.player = AVPlayer(url: url!)
//            
//            print(audioPlayer)
//            
//            GettingMoviesData.shared.audioSongs.append(audioPlayer)
//        }
//    }
}

