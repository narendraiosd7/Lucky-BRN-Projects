//
//  MoviesDetails.swift
//  UIImageView
//
//  Created by Vadde Narendra on 11/30/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class MoviesDetails: UIViewController
{

    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var movieTitleLbl: UILabel!
    @IBOutlet weak var directorNameLbl: UILabel!
    @IBOutlet weak var storyLbl: UILabel!
    @IBOutlet weak var actorsStackView: UIStackView!
    @IBOutlet weak var trailerView: UIView!
    @IBOutlet weak var audioStackView: UIStackView!
    
    var avPlayer:AVPlayerViewController!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        posterImageView.image = GettingMoviesData.shared.moviePosterImage[GettingMoviesData.shared.movieBtnTags]
        movieTitleLbl.text = GettingMoviesData.shared.MoviesTitle[GettingMoviesData.shared.movieBtnTags]
        directorNameLbl.text = GettingMoviesData.shared.directorName[GettingMoviesData.shared.movieBtnTags]
        storyLbl.text = GettingMoviesData.shared.moviesStory[GettingMoviesData.shared.movieBtnTags]
        
    print("**************************\(GettingMoviesData.shared.audioSongsPaths)***************************")
        
        actorsDeatils()
        
        movieVideosDeatils()

//        movieAudioDetails()
    }
    
    func actorsDeatils()
    {
        for i in GettingMoviesData.shared.actorsNames[GettingMoviesData.shared.movieBtnTags]
        {
            let actorsNameLbl =  UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 30))
            actorsNameLbl.text = "\(i)"
            actorsStackView.addArrangedSubview(actorsNameLbl)
        }
    }
    
    func movieVideosDeatils()
    {
        avPlayer = AVPlayerViewController()
        avPlayer = GettingMoviesData.shared.movieTrailer[GettingMoviesData.shared.movieBtnTags]
        avPlayer.view.frame = CGRect(x: 0 , y: 0, width: trailerView.frame.width, height: trailerView.frame.height)
        trailerView.addSubview(avPlayer.view)
    }
    
//    func movieAudioDetails()
//    {
//        var audioSongs = GettingMoviesData.shared.audioSongs
//
//        print("88888888888888888888888***********\(audioSongs)***********88888888888888888888888")
//
//
//        for i in audioSongs
//        {
//
//        }
//    }
    
    
    @IBAction func backBtnTapped(_ sender: UIButton)
    {
        dismiss(animated: true, completion: nil)
    }
    
}
