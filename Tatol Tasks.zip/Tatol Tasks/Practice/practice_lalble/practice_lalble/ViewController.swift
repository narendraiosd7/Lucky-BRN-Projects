//
//  ViewController.swift
//  practice_lalble
//
//  Created by Vadde Narendra on 9/7/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var nameLbl : UILabel!
    
    var URLReqObj:URLRequest!
    
    var dataTaskObj:URLSessionDataTask!
    
    @IBOutlet weak var stateNameLbl: UILabel!
    
    @IBOutlet weak var cityNameLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        nameLbl = UILabel()
//        nameLbl.frame = CGRect(x: 10, y: 250, width: 100, height: 30)
//        nameLbl.text = "Varun"
//        nameLbl.backgroundColor = UIColor.yellow
//        view.addSubview(nameLbl)
////
//        let percentageSlider = UISlider(frame: CGRect(x: 10, y: 300, width: 500, height: 30))
//        percentageSlider.minimumValue = 0
//        percentageSlider.maximumValue = 100
//        view.addSubview(percentageSlider)
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func getStateName(_ sender: Any) {
        
        
        
    }
    
    @IBAction func getCiryName(_ sender: Any) {
        
        getCityName()
        
    }
    
    func getCityName(){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/IndiaDetails.php?type=city&quantity=10")!)
        
        URLReqObj.httpMethod = "GET"
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    self.cityNameLbl.text = convertedData[0]
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
}

