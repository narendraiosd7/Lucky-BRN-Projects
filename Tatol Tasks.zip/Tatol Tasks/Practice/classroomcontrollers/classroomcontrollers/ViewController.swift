//
//  ViewController.swift
//  classroomcontrollers
//
//  Created by Vadde Narendra on 9/17/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let mainPowerSupplySwitch = UISwitch(frame: CGRect(x: 292, y: 75, width: 10, height: 10))
        mainPowerSupplySwitch.tintColor = UIColor.black
        mainPowerSupplySwitch.thumbTintColor = UIColor.black
        mainPowerSupplySwitch.onTintColor = UIColor.darkGray
        
        view.addSubview(mainPowerSupplySwitch)
        
        let fluorescentLamp1 = UISwitch(frame: CGRect(x: 292, y: 115, width: 10, height: 10))
        fluorescentLamp1.tintColor = UIColor.black
        fluorescentLamp1.thumbTintColor = UIColor.black
        fluorescentLamp1.onTintColor = UIColor.darkGray
        
        view.addSubview(fluorescentLamp1)
        
        let fluorescentLamp2 = UISwitch(frame: CGRect(x: 292, y: 150, width: 10, height: 10))
        fluorescentLamp2.tintColor = UIColor.black
        fluorescentLamp2.thumbTintColor = UIColor.black
        fluorescentLamp2.onTintColor = UIColor.darkGray
        
        view.addSubview(fluorescentLamp2)
        
        let ceilingFan1 = UISwitch(frame: CGRect(x: 292, y: 200, width: 10, height: 10))
        ceilingFan1.tintColor = UIColor.black
        ceilingFan1.thumbTintColor = UIColor.black
        ceilingFan1.onTintColor = UIColor.darkGray
        
        view.addSubview(ceilingFan1)
        
        let ceilingFan2 = UISwitch(frame: CGRect(x: 292, y: 75, width: 10, height: 10))
        ceilingFan2.tintColor = UIColor.black
        ceilingFan2.thumbTintColor = UIColor.black
        ceilingFan2.onTintColor = UIColor.darkGray
        
        view.addSubview(ceilingFan2)
        
        
        mainPowerSupplySwitch.addTarget(self, action: Selector(("switches:")), for:UIControl.Event.touchUpInside )

        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
   @objc func switches(lamp1:UISwitch,lamp2:UISwitch,main:UISwitch) {
        if (main.isOn == false){
            lamp1.setOn(false, animated: true)
            lamp1.isEnabled = false
            lamp2.setOn(false, animated: true)
            lamp2.isEnabled = false
        } else {
            lamp1.setOn(false, animated: true)
            lamp1.isEnabled = true
            lamp2.setOn(false, animated: true)
            lamp2.isEnabled = true
        }
    }
    
    
}

