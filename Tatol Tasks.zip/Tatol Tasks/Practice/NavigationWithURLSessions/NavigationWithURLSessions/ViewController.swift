//
//  ViewController.swift
//  NavigationWithURLSessions
//
//  Created by Vadde Narendra on 9/14/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var URLReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    
    @IBOutlet weak var registeredEmail: UITextField!
    @IBOutlet weak var registeredPassword: UITextField!
    
    let getUSerDetails:UserDetails = UserDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        getUserDeatils.getValidateLogin()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func getUserDeatils(_ sender: Any) {
        
//        print(registeredEmail.text)
        
        getUSerDetails.getValidateLogin(email: registeredEmail.text!, password: registeredPassword.text!)
    }
    @IBAction func getHolidays(_ sender: Any) {
        
            getUSerDetails.getUserHolidays()
        
    }
    
    @IBAction func getLeaves(_ sender: Any) {
    }
    
    @IBAction func getLateComes(_ sender: Any) {
    }
    @IBAction func getWorkingHours(_ sender: Any) {
    }
}

