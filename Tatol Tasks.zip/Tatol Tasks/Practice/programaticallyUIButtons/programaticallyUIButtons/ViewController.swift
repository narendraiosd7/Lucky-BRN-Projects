//
//  ViewController.swift
//  programaticallyUIButtons
//
//  Created by Vadde Narendra on 9/7/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var URLReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    var dataLbl:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        dataLbl = UILabel(frame: CGRect(x: 10, y: 150, width: 300, height: 60))
        
        view.addSubview(dataLbl)
        
        let getDataFromServerBtn = UIButton(type: UIButton.ButtonType.system)
        
        getDataFromServerBtn.frame = CGRect(x: 10, y: 100, width: 250, height: 50)
        
        view.addSubview(getDataFromServerBtn)
        
        getDataFromServerBtn.setTitle("Get Data", for: UIControl.State.normal)
        
        getDataFromServerBtn.addTarget(self, action: #selector(onGetDataBtnTap), for: .touchUpInside)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @objc func onGetDataBtnTap(){
    
        getActorsQuoteName()
        
    }
    
    func getActorsQuoteName(){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/Quotes.php")!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = "type=actor&quantity=10"
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    self.dataLbl.text = "\(convertedData[0])"
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    

}

