//
//  ViewController.swift
//  URLsessions_Practice
//
//  Created by Vadde Narendra on 8/29/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var URLReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       getIndiaDetails()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func getIndiaDetails(){
        
        URLReqObj = URLRequest.init(url: URL(string: "https://www.brninfotech.com/tws/IndiaDetails.php?type=state&quantity=20")!)
        
        URLReqObj.httpMethod = "GET"
        
//        let dataToSend = "type=actor&quantity=1"
//
//        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)

        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do {
                var convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
            }
            catch {
                print("Something is FASAK")
            }
        })
        
        dataTaskObj.resume()
        
    }
}
