//
//  ViewController.swift
//  DatepickerAndAlertMsgs
//
//  Created by Vadde Narendra on 10/24/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit
import TextFieldEffects

class ViewController: UIViewController, UITextFieldDelegate {
    
    var loginEmail = UITextField()
    var loginPassword = UITextField()
    var signInBtn = UIButton()
    var signUpBtn = UIButton()
    var signUpViewController:UIViewController!
    
    var alertControl = UIAlertController()
    var actionControl = UIAlertAction()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        creatingSignInLbls(xPos: 20, yPos: 400, myLblName: "E-Mail:")
        creatingSignInLbls(xPos: 20, yPos: 520, myLblName: "Password:")
        creatingSignInLbls(xPos: 80, yPos: 720, myLblName: "Don't have an account?")
        
        creatingSignInTFs()
        creatingBtns()
        
        signUpBtn.addTarget(self, action: #selector(signUpBtnTapped), for: UIControl.Event.touchUpInside)
        signInBtn.addTarget(self, action: #selector(signInBtnTapped), for: UIControl.Event.touchUpInside)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    // creating labels
    
    func creatingSignInLbls(xPos:Int, yPos:Int, myLblName:String)
    {
        let myLbl = UILabel(frame: CGRect(x: xPos, y: yPos, width: 400, height: 40))
        myLbl.text = myLblName
        myLbl.textColor = UIColor.black
        myLbl.font = UIFont.boldSystemFont(ofSize: 25)
        myLbl.font = UIFont.systemFont(ofSize: 25)
        myLbl.font = UIFont.italicSystemFont(ofSize: 25)
        view.addSubview(myLbl)
    }
    
    // creating textfields
    
    func creatingSignInTFs()
    {
        loginEmail = KaedeTextField(frame: CGRect(x: 20, y: 450, width: 380, height: 50))
        loginEmail.placeholder = "Enter your email"
        loginEmail.backgroundColor = UIColor.white
        loginEmail.keyboardType = UIKeyboardType.emailAddress
        loginEmail.delegate = self
        view.addSubview(loginEmail)
        
        loginPassword = KaedeTextField(frame: CGRect(x: 20, y: 570, width: 380, height: 50))
        loginPassword.placeholder = "Enter your password"
        loginPassword.backgroundColor = UIColor.white
        loginPassword.isSecureTextEntry = true
        loginPassword.keyboardType = UIKeyboardType.default
        loginPassword.delegate = self
        view.addSubview(loginPassword)
    }
    
    // creating buttons
    
    func creatingBtns()
    {
        signInBtn = UIButton(frame: CGRect(x: 162, y: 655, width: 90, height: 50))
        signInBtn.backgroundColor = UIColor.black
        signInBtn.setTitle("Sign In", for: UIControl.State.normal)
        view.addSubview(signInBtn)
        
        signUpBtn = UIButton(frame: CGRect(x: 162, y: 780, width: 90, height: 50))
        signUpBtn.backgroundColor = UIColor.black
        signUpBtn.setTitle("Sign Up", for: UIControl.State.normal)
        view.addSubview(signUpBtn)
    }
    
    // button function for sign up
    
    @objc func signUpBtnTapped()
    {
        let mainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpView = mainStoryBoard.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        self.navigationController?.pushViewController(signUpView, animated: true)
    }
    
    @objc func signInBtnTapped()
    {
        if ((loginPassword.text?.isEmpty)! ||
            (loginEmail.text?.isEmpty)!)
        {
            alertMsgs(titleName: "WARNING", messageDetails: "Please enter valid details")
        }
        else
        {
            alertMsgs(titleName: "CONGRATULATIONS", messageDetails: "successfully you have entered into your account")
        }
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        var returnValue:Bool = false
        
        if (textField == loginEmail)
        {
            returnValue = true
        }
        
        if (textField == loginPassword)
        {
            if ((loginEmail.text?.count)! >= 1)
            {
                returnValue = true
            } else
            {
                returnValue = false
            }
        }
        
        return returnValue
    }// return NO to disallow editing.
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        
    }// became first responder
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if(textField == loginEmail)
        {
            if(isValidEmail(emailStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter email and it's farmat like xxxx@xxxx.xxx")
                textField.textColor = .red
            }
            
        }
        
        if(textField == loginPassword)
        {
            if(isValidPassword(emailStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                alertMsgs(titleName: "WARNING", messageDetails: "Enter password it's must have minimum 8 characters at least 1 Uppercase Alphabet, 1 Lowercase Alphabet and 1 Number")
                textField.textColor = .red
            }
            
        }
        
        return true
    }// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        
    }// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }// called when clear button pressed. return NO to ignore (no notifications)
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return true
    }// called when 'return' key pressed. return NO to ignore.
    
    // function creating for email validation
    
    func isValidEmail(emailStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    // function creating for password validation
    
    func isValidPassword(emailStr:String) -> Bool {
        
        let emailRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    // alert msg function
    
    func alertMsgs(titleName:String, messageDetails:String)
    {
        alertControl = UIAlertController(title: titleName, message: messageDetails, preferredStyle: UIAlertController.Style.alert)
        actionControl = UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        alertControl.addAction(actionControl)
        self.present(alertControl, animated: true, completion: nil)
    }
    
}
