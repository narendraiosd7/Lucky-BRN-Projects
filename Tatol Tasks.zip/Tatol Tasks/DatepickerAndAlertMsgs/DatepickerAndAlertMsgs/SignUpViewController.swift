//
//  SignUpViewController.swift
//  DatepickerAndAlertMsgs
//
//  Created by Vadde Narendra on 10/24/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import Foundation

import UIKit

import TextFieldEffects

class SignUpViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
    
    var firstNameTF = UITextField()
    var lastNameTF = UITextField()
    var ageTF = UITextField()
    var mobileNoTF = UITextField()
    var emailTF = UITextField()
    var addressTV = UITextView()
    var stateNameTF = UITextField()
    var countryNameTF = UITextField()
    
    var submitBtn = UIButton()
    
    var alertControl = UIAlertController()
    var actionControl = UIAlertAction()
    
    var datePick = UIDatePicker()
    var ageCalculationLbl = UILabel()
    let dateCalendar = Calendar.current
    let todayDays = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        creatingSignUpLbls(xPos: 20, yPos: 80, myLblName: "First Name:")
        creatingSignUpLbls(xPos: 20, yPos: 160, myLblName: "Last Name:")
        creatingSignUpLbls(xPos: 20, yPos: 240, myLblName: "Age:")
        creatingSignUpLbls(xPos: 20, yPos: 360, myLblName: "Mobile Number:")
        creatingSignUpLbls(xPos: 20, yPos: 440, myLblName: "E-Mail:")
        creatingSignUpLbls(xPos: 20, yPos: 520, myLblName: "Address:")
        creatingSignUpLbls(xPos: 20, yPos: 660, myLblName: "State:")
        creatingSignUpLbls(xPos: 20, yPos: 740, myLblName: "Country:")
        
        creatingSignUpTFsAndTVs()
        
        creatingBtn()
        
        submitBtn.addTarget(self, action: #selector(submitBtnTapped), for: UIControl.Event.touchUpInside)
        
        showDate()
    
    }
    
    // Keyboard Controll
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    // creating labels
    
    func creatingSignUpLbls(xPos:Int, yPos:Int, myLblName:String)
    {
        let myLbl = UILabel(frame: CGRect(x: xPos, y: yPos, width: 400, height: 40))
        myLbl.text = myLblName
        myLbl.textColor = UIColor.white
        myLbl.font = UIFont.boldSystemFont(ofSize: 15)
        myLbl.font = UIFont.systemFont(ofSize: 15)
        myLbl.font = UIFont.italicSystemFont(ofSize: 15)
        view.addSubview(myLbl)
    }
    
    // creating textfields
    
    func creatingSignUpTFsAndTVs()
    {
        firstNameTF = KaedeTextField(frame: CGRect(x: 20, y: 120, width: 380, height: 30))
        firstNameTF.placeholder = "Enter first name"
        firstNameTF.backgroundColor = UIColor.white
        firstNameTF.keyboardType = UIKeyboardType.alphabet
        firstNameTF.delegate = self
        view.addSubview(firstNameTF)
        
        lastNameTF = KaedeTextField(frame: CGRect(x: 20, y: 200, width: 380, height: 30))
        lastNameTF.placeholder = "Enter last name"
        lastNameTF.backgroundColor = UIColor.white
        lastNameTF.keyboardType = UIKeyboardType.alphabet
        lastNameTF.delegate = self
        view.addSubview(lastNameTF)
        
        ageTF = KaedeTextField(frame: CGRect(x: 20, y: 280, width: 380, height: 30))
        ageTF.placeholder = "Enter age"
        ageTF.backgroundColor = UIColor.white
        ageTF.delegate = self
        view.addSubview(ageTF)
        
        mobileNoTF = KaedeTextField(frame: CGRect(x: 20, y: 400, width: 380, height: 30))
        mobileNoTF.placeholder = "Enter mobile number"
        mobileNoTF.backgroundColor = UIColor.white
        mobileNoTF.keyboardType = UIKeyboardType.phonePad
        mobileNoTF.delegate = self
        view.addSubview(mobileNoTF)
        
        emailTF = KaedeTextField(frame: CGRect(x: 20, y: 480, width: 380, height: 30))
        emailTF.placeholder = "Enter email address"
        emailTF.backgroundColor = UIColor.white
        emailTF.keyboardType = UIKeyboardType.emailAddress
        emailTF.delegate = self
        view.addSubview(emailTF)
        
        addressTV = UITextView(frame: CGRect(x: 20, y: 560, width: 380, height: 100))
        addressTV.backgroundColor = UIColor.white
        addressTV.keyboardType = UIKeyboardType.default
        addressTV.delegate = self
        view.addSubview(addressTV)
        
        stateNameTF = KaedeTextField(frame: CGRect(x: 20, y: 700, width: 380, height: 30))
        stateNameTF.placeholder = "Enter state"
        stateNameTF.backgroundColor = UIColor.white
        stateNameTF.keyboardType = UIKeyboardType.namePhonePad
        stateNameTF.delegate = self
        view.addSubview(stateNameTF)
        
        countryNameTF = KaedeTextField(frame: CGRect(x: 20, y: 780, width: 380, height: 30))
        countryNameTF.placeholder = "Enter country"
        countryNameTF.backgroundColor = UIColor.white
        countryNameTF.keyboardType = UIKeyboardType.namePhonePad
        countryNameTF.delegate = self
        view.addSubview(countryNameTF)
        
    }
    
    // creating button
    
    func creatingBtn()
    {
        submitBtn = UIButton(frame: CGRect(x: 162, y: 830, width: 90, height: 40))
        submitBtn.backgroundColor = UIColor.black
        submitBtn.setTitle("SUBMIT", for: UIControl.State.normal)
        view.addSubview(submitBtn)
        
    }
    
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        var returnValue:Bool = true
        
        if (textField == firstNameTF)
        {
            returnValue = true
        } else if (textField == lastNameTF)
        {
            if ((firstNameTF.text?.count)! >= 1)
            {
                returnValue = true
            } else
            {
                returnValue = false
            }
        }
        else if (textField == ageTF)
        {
            if ((lastNameTF.text?.count)! >= 1)
            {
                returnValue = true
            } else
            {
                returnValue = false
            }
        }else if (textField == mobileNoTF)
        {
            if ((lastNameTF.text?.count)! >= 1)
            {
                returnValue = true
            } else
            {
                returnValue = false
            }
        } else if (textField == emailTF)
        {
            if ((mobileNoTF.text?.count)! <= 15)
            {
                returnValue = true
            } else
            {
                returnValue = false
            }
        } else if (textField == stateNameTF)
        {
            if ((addressTV.text?.count)! >= 1)
            {
                returnValue = true
            } else
            {
                returnValue = false
            }
        } else if (textField == countryNameTF)
        {
            if ((stateNameTF.text?.count)! >= 1)
            {
                returnValue = true
            } else
            {
                returnValue = false
            }
        }
        
        return returnValue
    }// return NO to disallow editing.
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.textColor = UIColor.red
    }// became first responder
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if(textField ==  firstNameTF ||
            textField == lastNameTF ||
            textField == stateNameTF ||
            textField == countryNameTF)
        {
            if(isValidName(nameStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                textField.textColor = .red
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter only alphabets and enter minimum 2 letters")
            }
            
        }
        if(textField == emailTF)
        {
            if(isValidEmail(emailStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter email and it's format like xxxx@xxxx.xxx")
                textField.textColor = .red
            }
            
        }
        if(textField == mobileNoTF){
            if(isValidMobileNo(mobileNoStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter Mobile number in numarics and it's format like +9XXXXXXXXXXX")
                textField.textColor = .red
            }
            
        }
        return true
    }// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.textColor = UIColor.black
    }// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }// called when clear button pressed. return NO to ignore (no notifications)
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return true
    }// called when 'return' key pressed. return NO to ignore.
    
    // function creating for email validation
    
    func isValidEmail(emailStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    // function creating for name validation
    
    func isValidName(nameStr:String) -> Bool {
        
        let nameRegEx = "[A-Za-z ]{2,50}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        return emailPred.evaluate(with: nameStr)
    }
    
    // function creating for mobile number validation
    
    func isValidMobileNo(mobileNoStr : String) -> Bool {
        
        let mobileNoRegEx = "^((\\+)|(0))[0-9]{6,14}$"
        
        let mobileNoPred = NSPredicate(format: "SELF MATCHES %@",mobileNoRegEx)
        return mobileNoPred.evaluate(with: mobileNoStr)
    }
    
    // function creating for age validation
    
    func isValidAge(ageStr : String) -> Bool {
        
        let ageRegEx = "[0-9]{1,3}$"
        
        let agePred = NSPredicate(format: "SELF MATCHES %@",ageRegEx)
        return agePred.evaluate(with: ageStr)
    }
    
    // alert msg function
    
    func alertMsgs(titleName:String, messageDetails:String)
    {
        alertControl = UIAlertController(title: titleName, message: messageDetails, preferredStyle: UIAlertController.Style.alert)
        self.present(alertControl, animated: true, completion: nil)
        actionControl = UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        alertControl.addAction(actionControl)
        
    }
    
    // return NO to disallow editing.
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool
    {
        var returnValue:Bool = false
        
        if(textView == addressTV){
            if(mobileNoTF.text!.count >= 6){
                returnValue = true
            }else{
                returnValue = false
            }
        }
        return returnValue
    }
    
    // became first responder
    
    func textViewDidBeginEditing(_ textView: UITextView)
    {
        textView.textColor = UIColor.red
    }
    
    // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    
    func textViewDidEndEditing(_ textView: UITextView)
    {
        textView.textColor = UIColor.black
    }
    
    // function for event handle of date picker
    
    @objc func handleDatePicker(datePick:UIDatePicker)
    {
        ageCalculationLbl.removeFromSuperview()
        
        let pickerDateFormatter = DateFormatter()
        pickerDateFormatter.dateFormat = "YYYY-MM-dd"
        ageTF.text = pickerDateFormatter.string(from: datePick.date)
        
        ageTF.resignFirstResponder()
        
        let dateOfBirth = pickerDateFormatter.date(from: ageTF.text!)
        
        let calender = Calendar.current
        
        let dateComponent = calender.dateComponents([.year, .month, .day], from:
            dateOfBirth!, to: Date())
        
        ageCalculationLbl = UILabel(frame: CGRect(x: 65, y: 320, width: 300, height: 20))
        ageCalculationLbl.text = "\(dateComponent.year!) Year \(dateComponent.month!) Month \(dateComponent.day ?? 0) Day"
        ageCalculationLbl.textColor = UIColor.white
        ageCalculationLbl.font = UIFont.boldSystemFont(ofSize: 15)
        ageCalculationLbl.font = UIFont.systemFont(ofSize: 15)
        ageCalculationLbl.font = UIFont.italicSystemFont(ofSize: 15)
        ageCalculationLbl.textAlignment = .center
        view.addSubview(ageCalculationLbl)
    }
    
    // submit button
    
    @objc func submitBtnTapped()
    {
            if ((firstNameTF.text?.isEmpty)! ||
                (lastNameTF.text?.isEmpty)! ||
                (ageTF.text?.isEmpty)! ||
                (mobileNoTF.text?.isEmpty)! ||
                (emailTF.text?.isEmpty)! ||
                (addressTV.text?.isEmpty)! ||
                (stateNameTF.text?.isEmpty)! ||
                (countryNameTF.text?.isEmpty)!)
            {
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter valid details")
            }
            else
            {
                alertMsgs(titleName: "CONGRATULATIONS", messageDetails: "successfully created your account")
            }
            
        }
    
    // function creating for minimum & maximum age setting and event hamdler calling
    
    func showDate()
    {
        datePick.datePickerMode = UIDatePicker.Mode.date
        
        let minDateCalendar = Calendar.current
        
        var minDateComponent = minDateCalendar.dateComponents([.day,.month,.year], from: datePick.date)
        minDateComponent.day = 01
        minDateComponent.month = 01
        minDateComponent.year = 1970
        
        datePick.minimumDate = minDateCalendar.date(from: minDateComponent)
        
        let maxDate = Date()
        
        let maxDateCalender = Calendar.current
        
        var maxDateComponent = maxDateCalender.dateComponents([.day,.month,.year], from: Date())
        maxDateComponent.day = maxDateCalender.component(.day, from: maxDate)
        maxDateComponent.month = maxDateCalender.component(.month, from: maxDate)
        maxDateComponent.year = maxDateCalender.component(.year, from: maxDate)
        
        datePick.maximumDate = maxDateCalender.date(from: maxDateComponent)
        
        datePick.addTarget(self, action: #selector(handleDatePicker(datePick:)), for: UIControl.Event.valueChanged)
        
        ageTF.inputView = datePick
    }
    
}
