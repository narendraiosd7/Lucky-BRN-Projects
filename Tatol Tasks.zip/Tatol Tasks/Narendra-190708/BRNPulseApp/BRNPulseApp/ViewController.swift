//
//  ViewController.swift
//  BRNPulseApp
//
//  Created by Vadde Narendra on 10/26/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var signInBtn = UIButton()
    var signUpBtn = UIButton()
    var passwordForgotBtn = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let logo = UIImageView(frame: CGRect(x: 0, y: 0, width: 414, height: 414))
        logo.image = UIImage(named: "logo")
        logo.layer.cornerRadius = logo.frame.size.width / 1;
        logo.clipsToBounds = true
        view.addSubview(logo)
        
        creatingLblComponents(xPos: 20, yPos: 450, labelName: "Email:")
        creatingLblComponents(xPos: 20, yPos: 550, labelName: "Password:")
        
        creatingTFComponents()
        
        creatingBtnComponents()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func creatingLblComponents(xPos: Int, yPos: Int, labelName: String)
    {
        let myLbl = UILabel(frame: CGRect(x: xPos, y: yPos, width: 120, height: 60))
        myLbl.text = labelName
        myLbl.textColor = UIColor.black
        myLbl.font = UIFont.boldSystemFont(ofSize: 25)
        myLbl.font = UIFont.italicSystemFont(ofSize: 25)
        myLbl.font = UIFont.systemFont(ofSize: 25)
        view.addSubview(myLbl)
    }
    
    func creatingTFComponents()
    {
        let emailTF = UITextField(frame: CGRect(x: 20, y: 510, width: 380, height: 40))
        emailTF.placeholder = "Please enter email address"
        emailTF.backgroundColor = UIColor.white
        view.addSubview(emailTF)
        
        let passwordTF = UITextField(frame: CGRect(x: 20, y: 610, width: 380, height: 40))
        passwordTF.placeholder = "Please enter password"
        passwordTF.backgroundColor = UIColor.white
        passwordTF.isSecureTextEntry = true
        view.addSubview(passwordTF)
    }
    
    func creatingBtnComponents()
    {
        signInBtn = UIButton(frame: CGRect(x: 162, y: 670, width: 80, height: 40))
        signInBtn.backgroundColor = UIColor.black
        signInBtn.setTitle("LOGIN", for: UIControl.State.normal)
        signInBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        signInBtn.titleLabel?.font = UIFont.systemFont(ofSize: 25)
        view.addSubview(signInBtn)
        
        passwordForgotBtn = UIButton(frame: CGRect(x: 175, y: 720, width: 250, height: 80))
        passwordForgotBtn.setTitle("FORGOT PASSWORD?", for: UIControl.State.normal)
        passwordForgotBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        passwordForgotBtn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        view.addSubview(passwordForgotBtn)
        
        signUpBtn = UIButton(frame: CGRect(x: 0, y: 810, width: 414, height: 80))
        signUpBtn.setTitle("CREAT AN ACCOUNT", for: UIControl.State.normal)
        signUpBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        signUpBtn.titleLabel?.font = UIFont.systemFont(ofSize: 25)
        signUpBtn.backgroundColor = UIColor.black
        view.addSubview(signUpBtn)
        
    }
    

}

