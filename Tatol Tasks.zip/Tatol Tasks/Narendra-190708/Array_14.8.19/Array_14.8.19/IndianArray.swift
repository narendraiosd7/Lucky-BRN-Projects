//
//  IndianArray.swift
//  Array_14.8.19
//
//  Created by Vadde Narendra on 14/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import Foundation

struct India {
    
    
    init (districtName:String,headquarters:String){
        
        print(districtName)
        print(headquarters)
    }
    
}
    
    
    
    
    
    
//    var northRegionStates = ["Delhi","Haryana","Jammu and Kashmir","Himachal Pradesh","Uttarpradesh","Punjab","Uttarakhand"]
//
//    var southRegionStates = ["Andhra Pradesh","Telangana","Karnataka","Kerala","Tamil Nadu","Puducherry","Lakshadweep","Andaman and Nicobar"]
//
//    var eastRegionStates = ["West Bengal","Bihar","Jharkhand","Odisha"]
//
//    var westRegionStates = ["Dadra and Nagar Haveli","Daman and Diu","Goa","Gujarat","Maharashtra","Rajasthan"]
//
//    var india:[[String]] = [northRegionStates,southRegionStates,eastRegionStates,westRegionStates]
//
//
    
    

