//
//  ViewController.swift
//  Array_14.8.19
//
//  Created by Vadde Narendra on 14/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // North region districts & States
        
        print("---------- North Region States ----------")
        
        print("---------- Delhi State Districts ----------")
        
        // Delhi region districts
        
        let newDelhi = District(districtName: "New Delhi", headquarters: "Connaught Place")
        
        let centralDelhi = District(districtName: "Central Delhi", headquarters: "Daryaganj")
        
        let shahdara = District(districtName: "Shahdara", headquarters: "Shahdara")
        
        // Array for Delhi State
        
        var delhi:Array = [newDelhi,centralDelhi,shahdara]
        
        // Printing of Delhi districts details
        
        print(delhi[0].headquarters)
        
        print("---------- Haryana State Districts ----------")
        
        // Haryana region districts
        
        let ambala = District(districtName: "Ambala", headquarters: "Ambala")
        
        let bhiwani = District(districtName: "Bhiwani", headquarters: "Bhiwani")
        
        let charkhiDadri = District(districtName: "Charkhi Dadri", headquarters: "Charkhi Dadri")
        
        // Array for Haryana State
        
        var haryana:Array = [ambala,bhiwani,charkhiDadri]
        
        // Printing of Haryana districts details
        
        print(haryana[1].headquarters)
        
        print("---------- Uttarpradesh State Districts ----------")
        
        // Uttarpradesh region districts
        
        let firozabad = District(districtName: "Firozabad", headquarters: "Agra")
        
        let agra = District(districtName: "Agra", headquarters: "Agra")
        
        let mainpuri = District(districtName: "Mainpuri", headquarters: "Agra")
        
        // Array for Uttarpradesh State
        
        var uttarpradesh:Array = [firozabad,agra,mainpuri]
        
        // Printing of Uttarpradesh districts details
        
        print(uttarpradesh[2].headquarters)
        
        print("---------- Punjab State Districts ----------")
        
        // Punjab region districts
        
        let barnala = District(districtName: "Barnala", headquarters: "Barnala")
        
        let bathinda = District(districtName: "Bathinda", headquarters: "Bathinda")
        
        let faridkot = District(districtName: "Faridkot", headquarters: "Faridkot")
        
        // Array for Punjab State
        
        var punjab:Array = [barnala,bathinda,faridkot]
        
        // Printing of Punjab districts details
        
        print(punjab[2].headquarters)
        
        // North region states Array
        
        var northRegionStates:Array = [delhi,haryana,punjab]
        
        // States wise details printing
        
        print(northRegionStates[0][1])
        
        
        
        print("---------- South Region States ----------")
        
        // South region districts & States
        
        print("---------- Andhra Pradesh State Districts ----------")
        
        // Andhra Pradesh region districts
        
        let kurnool = District(districtName: "Kurnool", headquarters: "Kurnool")
        
        let chittoor = District(districtName: "Chittoor", headquarters: "Chittoor")
        
        let anantapur = District(districtName: "Anantapur", headquarters: "Anantapur")
        
        // Array for Andhra Pradesh State
        
        var andhraPradesh:Array = [kurnool,chittoor,anantapur]
        
        // Printing of Andhra Pradesh districts details
        
        print(andhraPradesh[0].headquarters)
        
        print("---------- Telangana State Districts ----------")
        
        // Telangana region districts
        
        let mancherial = District(districtName: "Mancherial", headquarters: "Mancherial")
        
        let hyderabad = District(districtName: "Hyderabad", headquarters: "Hyderabad")
        
        let medak = District(districtName: "Medak", headquarters: "Medak")
        
        // Array for Telangana State
        
        let telangana:Array = [mancherial,hyderabad,medak]
        
        // Printing of Telangana districts details
        
        print(andhraPradesh[0].headquarters)
        
        print("---------- Tamil Nadu State Districts ----------")
        
        // Tamil Nadu region districts
        
        let ariyalur = District(districtName: "Ariyalur", headquarters: "Ariyalur")
        
        let coimbatore = District(districtName: "Coimbatore", headquarters: "Coimbatore")
        
        let cuddalore = District(districtName: "Cuddalore", headquarters: "Cuddalore")
        
        // Array for Tamil Nadu State
        
        var tamilNadu:Array = [ariyalur,coimbatore,cuddalore]
        
        // Printing of Tamil Nadu districts details
        
        print(tamilNadu[1].headquarters)
        
        // South region states Array
        
        let southRegionStates:Array = [andhraPradesh,telangana,tamilNadu]
        
        
        
        print("---------- East Region States ----------")
        
        // East region districts & States
        
        print("---------- Bihar State Districts ----------")
        
        // Bihar region districts
        
        let araria = District(districtName: "Araria", headquarters: "Araria")
        
        let arwal = District(districtName: "Arwal", headquarters: "Arwal")
        
        let banka = District(districtName: "Banka", headquarters: "Banka")
        
        // Array for Bihar State
        
        var bihar:Array = [araria,arwal,banka]
        
        // Printing of Tamil Nadu districts details
        
        print(bihar[2].headquarters)
        
        print("---------- Odisha State Districts ----------")
        
        // Odisha region districts
        
        let angul = District(districtName: "Angul", headquarters: "Angul")
        
        let balangir = District(districtName: "Balangir", headquarters: "Balangir")
        
        let bhadrak = District(districtName: "Bhadrak", headquarters: "Bhadrak")
        
        // Array for Odisha State
        
        var odisha:Array = [angul,balangir,bhadrak]
        
        // Printing of Tamil Nadu districts details
        
        print(odisha[2].headquarters)
        
        print("---------- Jharkhand State Districts ----------")
        
        // Jharkhand region districts
        
        let bokaro = District(districtName: "Bokaro", headquarters: "Bokaro")
        
        let chatra = District(districtName: "Chatra", headquarters: "Chatra")
        
        let deoghar = District(districtName: "Deoghar", headquarters: "Deoghar")
        
        // Array for Jharkhand State
        
        var jharkhand:Array = [bokaro,chatra,deoghar]
        
        // Printing of Jharkhand districts details
        
        print(jharkhand[2].headquarters)
        
        // East region states Array
        
        let eastRegionStates:Array = [bihar,odisha,jharkhand]
        
        
        
        // west region districts & States
        
        print("---------- Gujarat State Districts ----------")
        
        // Gujarat region districts
        
        let ahmedabad = District(districtName: "Ahmedabad", headquarters: "Ahmedabad")
        
        let amreli = District(districtName: "Amreli", headquarters: "Amreli")
        
        let anand = District(districtName: "Anand", headquarters: "Anand")
        
        // Array for Gujarat State
        
        var gujarat:Array = [ahmedabad,amreli,anand]
        
        // Printing of Gujarat districts details
        
        print(gujarat[0].headquarters)
        
        print("---------- Maharashtra State Districts ----------")
        
        // Maharashtra region districts
        
        let amravati = District(districtName: "Amravati", headquarters: "Amravati")
        
        let akola = District(districtName: "Akola", headquarters: "Amravati")
        
        let washim = District(districtName: "Washim", headquarters: "Amravati")
        
        // Array for Maharashtra State
        
        var maharashtra:Array = [amravati,akola,washim]
        
        // Printing of Maharashtra districts details
        
        print(maharashtra[1].headquarters)
        
        print("---------- Rajasthan State Districts ----------")
        
        // Rajasthan region districts
        
        let ajmer = District(districtName: "Ajmer", headquarters: "Ajmer")
        
        let alwar = District(districtName: "Alwar", headquarters: "Alwar")
        
        let banswara = District(districtName: "Banswara", headquarters: "Banswara")
        
        // Array for Rajasthan State
        
        var rajasthan:Array = [ajmer,alwar,banswara]
        
        // Printing of Rajasthan districts details
        
        print(rajasthan[2].headquarters)
        
        // West region states Array
        
        var westRegionStates:Array = [gujarat,maharashtra,rajasthan]
        
        print(westRegionStates[0][1].districtName)
        
        // Array for Indian States
        
        let indiaStates: Array = [eastRegionStates, westRegionStates, northRegionStates, southRegionStates]
        
        print(indiaStates[0][0][0].districtName)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
}


