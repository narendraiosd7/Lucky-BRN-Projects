//
//  ViewController.swift
//  FunctionsWithReturntype
//
//  Created by BRN1907 on 31/07/19.
//  Copyright © 2019 BRN1907. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Person -1
        
        var vijay1stYearBtechResults = calFirstYearBtechResults(communicativeEngMarks: 85, enggPhysicsMarks: 88, enggChemistryMarks: 39, mathematics1Marks: 92, proCAndDatastructureMarks: 79, mathematics2Marks: 94, enggGraphicsMarks: 92, proCDatastrucLabMarks: 70, enggPhyAndEnggCheLabMarks: 68, enggAndITWorkShopMarks: 72, enggLangComSkillLabMarks: 65)
        
        var vijay2ndYear1stSemResults = cal2ndYear1stSemBtechResults(mathematics3Marks: 84, environmentalSciMarks: 75, basicFMHMMarks: 72, elecDevCirsMarks: 86, elecMachines1Marks: 87, elecCircuitsMarks: 92, basicFMHMLabMarks: 68)
        
        var vijay2ndYear2ndSemResults = cal2ndYear2ndSemBtechResults(EMFMarks: 74, GEPMarks: 71, AECMarks: 75, STLDMarks: 85, NTMarks: 65, EM2Marks: 48)
        
        var vijay3rdYear1stSemResults = cal3rdYear1stSemBtechResults(MEFAMarks: 79, EEMMarks: 95, TEPMarks: 84, CSMarks: 74, PEMarks: 68)

        var vijay3rdYear2ndSemResults = cal3rdYear2ndSemBtechResults(MSMarks: 74, PSDMarks: 72, PSAMarks: 84, MPMCMarks: 65)
        
        var vijay4thYear1stSemResults = cal4thYear1stSemBtechResults(DEPMarks: 78, DSPMarks: 84, fundametalsofHVDCFactsDevicesMarks: 62)
        
        var vijay4thYear2ndsemResults = cal4thYear2ndSemBtechResults()
        
        // Second Year B-Tech Results
        
        if (vijay2ndYear1stSemResults == true && vijay2ndYear2ndSemResults == true)
        {
            print("Passed 2nd Year B-Tech")
        } else {
            print("Failed 2nd Year B-Tech")
        }
        
        
        // Third Year B-tech Results
        
        if (vijay3rdYear1stSemResults == true && vijay3rdYear2ndSemResults == true)
        {
            print("Passed 3rd Year B-Tech")
        } else {
            print("Failed 3rd Year B-Tech")
        }
        
        
        // Forth Year B-Tech Results
        
        if (vijay4thYear1stSemResults == true && vijay4thYear2ndsemResults == true)
        {
            print("Passed 4th Year B-Tech")
        } else {
            print("Failed 4th Year B-Tech")
        }
        
        // Overall B-Tech Results
        
        if (vijay1stYearBtechResults == true && vijay2ndYear1stSemResults == true && vijay2ndYear2ndSemResults == true && vijay3rdYear1stSemResults == true && vijay3rdYear2ndSemResults == true && vijay4thYear1stSemResults == true && vijay4thYear2ndsemResults == true)
        {
            print("Passed B-Tech")
        } else {
            print("Failed B-Tech")
        }
        
        
        
        // Person -2
        
        var ajay1stYearBtechResults = calFirstYearBtechResults(communicativeEngMarks: 85, enggPhysicsMarks: 88, enggChemistryMarks: 39, mathematics1Marks: 92, proCAndDatastructureMarks: 79, mathematics2Marks: 94, enggGraphicsMarks: 92, proCDatastrucLabMarks: 70, enggPhyAndEnggCheLabMarks: 68, enggAndITWorkShopMarks: 72, enggLangComSkillLabMarks: 65)
        
        var ajay2ndYear1stSemResults = cal2ndYear1stSemBtechResults(mathematics3Marks: 84, environmentalSciMarks: 75, basicFMHMMarks: 72, elecDevCirsMarks: 86, elecMachines1Marks: 87, elecCircuitsMarks: 92, basicFMHMLabMarks: 68)
        
        var ajay2ndYear2ndSemResults = cal2ndYear2ndSemBtechResults(EMFMarks: 74, GEPMarks: 71, AECMarks: 75, STLDMarks: 85, NTMarks: 65, EM2Marks: 48)
        
        var ajay3rdYear1stSemResults = cal3rdYear1stSemBtechResults(MEFAMarks: 79, EEMMarks: 84, TEPMarks: 84, CSMarks: 74, PEMarks: 68)
        
        var ajay3rdYear2ndSemResults = cal3rdYear2ndSemBtechResults(MSMarks: 74, PSDMarks: 72, PSAMarks: 84, MPMCMarks: 65)
        
        var ajay4thYear1stSemResults = cal4thYear1stSemBtechResults(DEPMarks: 78, DSPMarks: 84, fundametalsofHVDCFactsDevicesMarks: 62)
        
        var ajay4thYear2ndsemResults = cal4thYear2ndSemBtechResults()
        
        
        // Second Year B-Tech Results
        
        if (ajay2ndYear1stSemResults == true && ajay2ndYear2ndSemResults == true)
        {
            print("Passed 2nd Year B-Tech")
        } else {
            print("Failed 2nd Year B-Tech")
        }
        
        
        // Third Year B-tech Results
        
        if (ajay3rdYear1stSemResults == true && ajay3rdYear2ndSemResults == true)
        {
            print("Passed 3rd Year B-Tech")
        } else {
            print("Failed 3rd Year B-Tech")
        }
        
        
        // Forth Year B-Tech Results
        
        if (ajay4thYear1stSemResults == true && ajay4thYear2ndsemResults == true)
        {
            print("Passed 4th Year B-Tech")
        } else {
            print("Failed 4th Year B-Tech")
        }
        
        // Overall B-Tech Results
        
        if (ajay1stYearBtechResults == true && ajay2ndYear1stSemResults == true && ajay2ndYear2ndSemResults == true && ajay3rdYear1stSemResults == true && ajay3rdYear2ndSemResults == true && ajay4thYear1stSemResults == true && ajay4thYear2ndsemResults == true)
        {
            print("Passed B-Tech")
        } else {
            print("Failed B-Tech")
        }
        
        
        
        // Person -3
        
        var sai1stYearBtechResults = calFirstYearBtechResults(communicativeEngMarks: 85, enggPhysicsMarks: 88, enggChemistryMarks: 39, mathematics1Marks: 92, proCAndDatastructureMarks: 79, mathematics2Marks: 94, enggGraphicsMarks: 92, proCDatastrucLabMarks: 70, enggPhyAndEnggCheLabMarks: 68, enggAndITWorkShopMarks: 72, enggLangComSkillLabMarks: 65)
        
        var sai2ndYear1stSemResults = cal2ndYear1stSemBtechResults(mathematics3Marks: 84, environmentalSciMarks: 75, basicFMHMMarks: 72, elecDevCirsMarks: 86, elecMachines1Marks: 87, elecCircuitsMarks: 92, basicFMHMLabMarks: 68)
        
        var sai2ndYear2ndSemResults = cal2ndYear2ndSemBtechResults(EMFMarks: 74, GEPMarks: 71, AECMarks: 75, STLDMarks: 85, NTMarks: 65, EM2Marks: 48)
        
        var sai3rdYear1stSemResults = cal3rdYear1stSemBtechResults(MEFAMarks: 43, EEMMarks: 95, TEPMarks: 84, CSMarks: 74, PEMarks: 68)
        
        var sai3rdYear2ndSemResults = cal3rdYear2ndSemBtechResults(MSMarks: 74, PSDMarks: 72, PSAMarks: 84, MPMCMarks: 65)
        
        var sai4thYear1stSemResults = cal4thYear1stSemBtechResults(DEPMarks: 78, DSPMarks: 84, fundametalsofHVDCFactsDevicesMarks: 62)
        
        var sai4thYear2ndsemResults = cal4thYear2ndSemBtechResults()
        
        // Second Year B-Tech Results
        
        if (sai2ndYear1stSemResults == true && sai2ndYear2ndSemResults == true)
        {
            print("Passed 2nd Year B-Tech")
        } else {
            print("Failed 2nd Year B-Tech")
        }
        
        
        // Third Year B-tech Results
        
        if (sai3rdYear1stSemResults == true && sai3rdYear2ndSemResults == true)
        {
            print("Passed 3rd Year B-Tech")
        } else {
            print("Failed 3rd Year B-Tech")
        }
        
        
        // Forth Year B-Tech Results
        
        if (sai4thYear1stSemResults == true && sai4thYear2ndsemResults == true)
        {
            print("Passed 4th Year B-Tech")
        } else {
            print("Failed 4th Year B-Tech")
        }
        
        // Overall B-Tech Results
        
        if (sai1stYearBtechResults == true && sai2ndYear1stSemResults == true && sai2ndYear2ndSemResults == true && sai3rdYear1stSemResults == true && sai3rdYear2ndSemResults == true && sai4thYear1stSemResults == true && sai4thYear2ndsemResults == true)
        {
            print("Passed B-Tech")
        } else {
            print("Failed B-Tech")
        }
        
        
        
        // Person - 4
        
        var ram1stYearBtechResults = calFirstYearBtechResults(communicativeEngMarks: 85, enggPhysicsMarks: 88, enggChemistryMarks: 39, mathematics1Marks: 92, proCAndDatastructureMarks: 79, mathematics2Marks: 94, enggGraphicsMarks: 92, proCDatastrucLabMarks: 70, enggPhyAndEnggCheLabMarks: 68, enggAndITWorkShopMarks: 72, enggLangComSkillLabMarks: 65)
        
        var ram2ndYear1stSemResults = cal2ndYear1stSemBtechResults(mathematics3Marks: 84, environmentalSciMarks: 75, basicFMHMMarks: 72, elecDevCirsMarks: 75, elecMachines1Marks: 87, elecCircuitsMarks: 92, basicFMHMLabMarks: 68)
        
        var ram2ndYear2ndSemResults = cal2ndYear2ndSemBtechResults(EMFMarks: 74, GEPMarks: 71, AECMarks: 75, STLDMarks: 85, NTMarks: 65, EM2Marks: 48)
        
        var ram3rdYear1stSemResults = cal3rdYear1stSemBtechResults(MEFAMarks: 79, EEMMarks: 95, TEPMarks: 84, CSMarks: 74, PEMarks: 68)
        
        var ram3rdYear2ndSemResults = cal3rdYear2ndSemBtechResults(MSMarks: 74, PSDMarks: 72, PSAMarks: 84, MPMCMarks: 65)
        
        var ram4thYear1stSemResults = cal4thYear1stSemBtechResults(DEPMarks: 78, DSPMarks: 84, fundametalsofHVDCFactsDevicesMarks: 62)
        
        var ram4thYear2ndsemResults = cal4thYear2ndSemBtechResults()
        
        // Second Year B-Tech Results
        
        if (ram2ndYear1stSemResults == true && ram2ndYear2ndSemResults == true)
        {
            print("Passed 2nd Year B-Tech")
        } else {
            print("Failed 2nd Year B-Tech")
        }
        
        
        // Third Year B-tech Results
        
        if (ram3rdYear1stSemResults == true && ram3rdYear2ndSemResults == true)
        {
            print("Passed 3rd Year B-Tech")
        } else {
            print("Failed 3rd Year B-Tech")
        }
        
        
        // Forth Year B-Tech Results
        
        if (ram4thYear1stSemResults == true && ram4thYear2ndsemResults == true)
        {
            print("Passed 4th Year B-Tech")
        } else {
            print("Failed 4th Year B-Tech")
        }
        
        // Overall B-Tech Results
        
        if (ram1stYearBtechResults == true && ram2ndYear1stSemResults == true && ram2ndYear2ndSemResults == true && ram3rdYear1stSemResults == true && ram3rdYear2ndSemResults == true && ram4thYear1stSemResults == true && ram4thYear2ndsemResults == true)
        {
            print("Passed B-Tech")
        } else {
            print("Failed B-Tech")
        }
        
        
        
        // Person - 5
        
        var siva1stYearBtechResults = calFirstYearBtechResults(communicativeEngMarks: 85, enggPhysicsMarks: 88, enggChemistryMarks: 39, mathematics1Marks: 92, proCAndDatastructureMarks: 79, mathematics2Marks: 94, enggGraphicsMarks: 92, proCDatastrucLabMarks: 70, enggPhyAndEnggCheLabMarks: 68, enggAndITWorkShopMarks: 72, enggLangComSkillLabMarks: 65)
        
        var siva2ndYear1stSemResults = cal2ndYear1stSemBtechResults(mathematics3Marks: 84, environmentalSciMarks: 75, basicFMHMMarks: 72, elecDevCirsMarks: 86, elecMachines1Marks: 87, elecCircuitsMarks: 92, basicFMHMLabMarks: 68)
        
        var siva2ndYear2ndSemResults = cal2ndYear2ndSemBtechResults(EMFMarks: 74, GEPMarks: 71, AECMarks: 75, STLDMarks: 85, NTMarks: 65, EM2Marks: 23)
        
        var siva3rdYear1stSemResults = cal3rdYear1stSemBtechResults(MEFAMarks: 79, EEMMarks: 95, TEPMarks: 84, CSMarks: 74, PEMarks: 68)
        
        var siva3rdYear2ndSemResults = cal3rdYear2ndSemBtechResults(MSMarks: 74, PSDMarks: 72, PSAMarks: 84, MPMCMarks: 65)
        
        var siva4thYear1stSemResults = cal4thYear1stSemBtechResults(DEPMarks: 78, DSPMarks: 84, fundametalsofHVDCFactsDevicesMarks: 62)
        
        var siva4thYear2ndsemResults = cal4thYear2ndSemBtechResults()
        
        // Second Year B-Tech Results
        
        if (siva2ndYear1stSemResults == true && siva2ndYear2ndSemResults == true)
        {
            print("Passed 2nd Year B-Tech")
        } else {
            print("Failed 2nd Year B-Tech")
        }
        
        
        // Third Year B-tech Results
        
        if (siva3rdYear1stSemResults == true && siva3rdYear2ndSemResults == true)
        {
            print("Passed 3rd Year B-Tech")
        } else {
            print("Failed 3rd Year B-Tech")
        }
        
        
        // Forth Year B-Tech Results
        
        if (siva4thYear1stSemResults == true && siva4thYear2ndsemResults == true)
        {
            print("Passed 4th Year B-Tech")
        } else {
            print("Failed 4th Year B-Tech")
        }
        
        // Overall B-Tech Results
        
        if (siva1stYearBtechResults == true && siva2ndYear1stSemResults == true && siva2ndYear2ndSemResults == true && siva3rdYear1stSemResults == true && siva3rdYear2ndSemResults == true && siva4thYear1stSemResults == true && siva4thYear2ndsemResults == true)
        {
            print("Passed B-Tech")
        } else {
            print("Failed B-Tech")
        }
        
        
        


        
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    
    
    
    

    func calFirstYearBtechResults(communicativeEngMarks:UInt8,enggPhysicsMarks:UInt8,enggChemistryMarks:UInt8,mathematics1Marks:UInt8,proCAndDatastructureMarks:UInt8,mathematics2Marks:UInt8,enggGraphicsMarks:UInt8,proCDatastrucLabMarks:UInt8,enggPhyAndEnggCheLabMarks:UInt8,enggAndITWorkShopMarks:UInt8,enggLangComSkillLabMarks:UInt8)-> Bool
    {
        
        // Calculating Total Marks
        
        let gained1stYearBtechMarks:UInt16 = UInt16(communicativeEngMarks)+UInt16(enggPhysicsMarks)+UInt16(enggChemistryMarks)+UInt16(enggGraphicsMarks)+UInt16(proCAndDatastructureMarks)+UInt16(enggPhyAndEnggCheLabMarks)+UInt16(enggAndITWorkShopMarks)+UInt16(enggLangComSkillLabMarks)+UInt16(mathematics2Marks)+UInt16(mathematics1Marks)
        
        print("Total Marks in B-Tech 1st Year = \(gained1stYearBtechMarks)")
        
        // Calculating Percentage
        
        let firstYearBtechTotalMarks:Float = 1000
        
        let firstYearBtechMarks:Float = Float(gained1stYearBtechMarks)
        
        let firstYearBtechPercentage:Float = (firstYearBtechMarks/firstYearBtechTotalMarks)*100
        
        print("B-Tech 1st Year Percentage = \(firstYearBtechPercentage)")
        
        // finding out 1st Year subject wise pass or fail
        
        var subPassMarks:UInt8 = 35
        var labPassMarks:UInt8 = 27
        
        var communicativeEnglish:Bool = false
        var engineeringPhysics:Bool = false
        var engineeringChemistry:Bool = false
        var engineeringGraphics:Bool = false
        var programmingCandDataStructure:Bool = false
        var engineeringPhysicsAndEngineeringChemistryLab:Bool = false
        var mathematics1:Bool = false
        var mathematics2:Bool = false
        var engineeringAndITWorkShop:Bool = false
        var englishLanguageCommunicationSkillLab:Bool = false
        var programmingCAndDataStructureLab:Bool = false
        
        if communicativeEngMarks >= subPassMarks
        {
            communicativeEnglish = true
        } else {
            communicativeEnglish = false
        }
        
        if enggGraphicsMarks >= subPassMarks
        {
            engineeringGraphics = true
        } else {
            engineeringGraphics = false
        }
        
        if enggChemistryMarks >= subPassMarks
        {
            engineeringChemistry = true
        } else {
            engineeringChemistry = false
        }

        if mathematics1Marks >= subPassMarks
        {
            mathematics1 = true
        } else {
            mathematics1 = false
        }
        
        if mathematics2Marks >= subPassMarks
        {
            mathematics2 = true
        } else {
            mathematics2 = false
        }
        
        if proCAndDatastructureMarks >= subPassMarks
        {
            programmingCandDataStructure = true
        } else {
            programmingCandDataStructure = false
        }
        
        if enggPhyAndEnggCheLabMarks >= labPassMarks
        {
            engineeringPhysicsAndEngineeringChemistryLab = true
        } else {
            engineeringPhysicsAndEngineeringChemistryLab = false
        }
        
        if enggAndITWorkShopMarks >= labPassMarks
        {
            engineeringAndITWorkShop = true
        } else {
            engineeringAndITWorkShop = false
        }
        
        if proCDatastrucLabMarks >= labPassMarks
        {
            programmingCAndDataStructureLab = true
        } else {
            programmingCAndDataStructureLab = false
        }
        
        if enggLangComSkillLabMarks >= labPassMarks
        {
            englishLanguageCommunicationSkillLab = true
        } else {
            englishLanguageCommunicationSkillLab = false
        }
        
        // finding out B-Tech 1st Year Passed or Failed and giving grade
        
       
        var firstYearBtechResults:Bool = false
        
        if (communicativeEnglish == true && engineeringGraphics == true && engineeringChemistry == true && mathematics1 == true && mathematics2 == true && programmingCandDataStructure == true && engineeringPhysicsAndEngineeringChemistryLab == true && engineeringAndITWorkShop == true && programmingCAndDataStructureLab == true && englishLanguageCommunicationSkillLab == true)
        {
            switch firstYearBtechPercentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            firstYearBtechResults = true
            print("Passed B-Tech 1st Year")
            
        }
        else
        {
            firstYearBtechResults = false
            print("Failed B-Tech 1st Year")
        }
        
        return firstYearBtechResults
    }
}




func cal2ndYear1stSemBtechResults(mathematics3Marks:UInt8,environmentalSciMarks:UInt8,basicFMHMMarks:UInt8,elecDevCirsMarks:UInt8,elecMachines1Marks:UInt8,elecCircuitsMarks:UInt8,basicFMHMLabMarks:UInt8,electronicDevCirsLabMarks:UInt8 = 70) -> Bool
{
    // Calculating Total Marks
    
    let secondYear1stSemGainedMarks:UInt16 = UInt16(mathematics3Marks)+UInt16(environmentalSciMarks)+UInt16(basicFMHMMarks)+UInt16(elecDevCirsMarks)+UInt16(elecMachines1Marks)+UInt16(elecCircuitsMarks)+UInt16(basicFMHMLabMarks)+UInt16(electronicDevCirsLabMarks)
    
    // Calculating Percentage
    
    let totalMarks1stSem:Float = 750
    
    let firstSemGainedMarks:Float = Float(secondYear1stSemGainedMarks)
    
    let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
    
    print("B-Tech 2nd Year 1st Sem Percentage = \(firstSemPercentage)")
    
    // finding out subject wise pass or fail
    
    var subPassMarks:UInt8 = 35
    var labPassMarks:UInt8 = 27
    
    var mathematics3:Bool = false
    var environmentalScience:Bool = false
    var basicFMHM:Bool = false
    var electronicDevicesAndCircuits:Bool = false
    var electricalMachines1:Bool = false
    var electricalCircuits:Bool = false
    var basicFMHMLab:Bool = false
    var electronicDevicesAndCircuitsLab:Bool = false
    
    if mathematics3Marks >= subPassMarks
    {
        mathematics3 = true
    } else {
        mathematics3 = false
    }
    
    if environmentalSciMarks >= subPassMarks
    {
        environmentalScience = true
    } else {
        environmentalScience = false
    }
    
    if basicFMHMMarks >= subPassMarks
    {
        basicFMHM = true
    } else {
        basicFMHM = false
    }
    
    if elecDevCirsMarks >= subPassMarks
    {
        electronicDevicesAndCircuits = true
    } else {
        electronicDevicesAndCircuits = false
    }
    
    if elecMachines1Marks >= subPassMarks
    {
        electricalMachines1 = true
    } else {
        electricalMachines1 = false
    }
    
    if elecCircuitsMarks >= subPassMarks
    {
        electricalCircuits = true
    } else {
        electricalCircuits = false
    }
    
    if basicFMHMLabMarks >= labPassMarks
    {
        basicFMHMLab = true
    } else {
        basicFMHMLab = false
    }
    
    if  electronicDevCirsLabMarks >= labPassMarks
    {
        electronicDevicesAndCircuitsLab = true
    } else {
        electronicDevicesAndCircuitsLab = false
    }
    
    // Total 2nd Year 1st Sem pass or fail with grade
    
    var secondYear1stSemResults:Bool = false
    
    if (mathematics3 == true && environmentalScience == true && basicFMHM == true && electronicDevicesAndCircuits == true && electricalMachines1 == true && electricalCircuits == true && basicFMHMLab == true && electronicDevicesAndCircuitsLab == true)
    {
        switch firstSemPercentage
        {
        case 90...100:
            print("Grade A")
        case 75..<90:
            print("Grade B")
        case 50..<75:
            print("Grade C")
        case 35..<50:
            print("Grade D")
        default:
            print("Grade E")
        }
        secondYear1stSemResults = true
        print("B-Tech 2nd Year 1st Sem Passed")
    }
    else
    {
        secondYear1stSemResults = false
        print("B-Tech 2nd Year 1st Sem Failed")
    }
    
    return secondYear1stSemResults
    
}




func cal2ndYear2ndSemBtechResults(EMFMarks:UInt8,GEPMarks:UInt8,AECMarks:UInt8,STLDMarks:UInt8,NTMarks:UInt8,EM2Marks:UInt8,EM1LabMarks:UInt8 = 71,ECSLabMarks:UInt8 = 72) -> Bool
{
    // Calculating Total Marks
    
    let secondYear2ndSemGainedMarks:UInt16 = UInt16(EMFMarks)+UInt16(GEPMarks)+UInt16(AECMarks)+UInt16(STLDMarks)+UInt16(EM2Marks)+UInt16(NTMarks)+UInt16(EM1LabMarks)+UInt16(ECSLabMarks)
    
    // Calculating Percentage
    
    let totalMarks2ndSem:Float = 750
    
    let secondSemGainedMarks:Float = Float(secondYear2ndSemGainedMarks)
    
    let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
    
    print("B-Tech 2nd Year 2nd Sem Percentage = \(secondSemPercentage)")
    
    // finding out subject wise pass or fail
    
    var subPassMarks:UInt8 = 35
    var labPassMarks:UInt8 = 27
    
    var electroMagneticField:Bool = false
    var generationofElectricalPower:Bool = false
    var analogElectroniccsAndCircuts:Bool = false
    var switchingThoeryAndLogicalDesign:Bool = false
    var electricalMachines2:Bool = false
    var NetworkTheory:Bool = false
    var electricalMachines1Lab:Bool = false
    var electricalCircuitsAndSimulationLab:Bool = false
    
    if EMFMarks >= subPassMarks
    {
        electroMagneticField = true
    } else {
        electroMagneticField = false
    }
    
    if GEPMarks >= subPassMarks
    {
        generationofElectricalPower = true
    } else {
        generationofElectricalPower = false
    }
    
    if AECMarks >= subPassMarks
    {
        analogElectroniccsAndCircuts = true
    } else {
        analogElectroniccsAndCircuts = false
    }
    
    if STLDMarks >= subPassMarks
    {
        switchingThoeryAndLogicalDesign = true
    } else {
        switchingThoeryAndLogicalDesign = false
    }
    
    if EM2Marks >= subPassMarks
    {
        electricalMachines2 = true
    } else {
        electricalMachines2 = false
    }
    
    if NTMarks >= subPassMarks
    {
        NetworkTheory = true
    } else {
        NetworkTheory = false
    }
    
    if EM1LabMarks >= labPassMarks
    {
        electricalMachines1Lab = true
    } else {
        electricalMachines1Lab = false
    }
    
    if  ECSLabMarks >= labPassMarks
    {
        electricalCircuitsAndSimulationLab = true
    } else {
        electricalCircuitsAndSimulationLab = false
    }
    
    // Total 2nd Year 2nd Sem pass or fail with grade
    
    var secondYear2ndSemResults:Bool = false
    
    if (electroMagneticField == true && generationofElectricalPower == true && switchingThoeryAndLogicalDesign == true && analogElectroniccsAndCircuts == true && electricalMachines2 == true && NetworkTheory == true && electricalMachines1Lab == true && electricalCircuitsAndSimulationLab == true)
    {
        switch secondSemPercentage
        {
        case 90...100:
            print("Grade A")
        case 75..<90:
            print("Grade B")
        case 50..<75:
            print("Grade C")
        case 35..<50:
            print("Grade D")
        default:
            print("Grade E")
        }
        secondYear2ndSemResults = true
        print("B-Tech 2nd Year 2nd Sem Passed")
    }
    else
    {
        secondYear2ndSemResults = false
        print("B-Tech 2nd Year 2nd Sem Failed")
    }
    
    return secondYear2ndSemResults
    
}



func cal3rdYear1stSemBtechResults(MEFAMarks:UInt8,EEMMarks:UInt8,TEPMarks:UInt8,CSMarks:UInt8,PEMarks:UInt8,EM3Marks:UInt8 = 86,EMLab2Marks:UInt8 = 68,CSSimLabMarks:UInt8 = 56) -> Bool
{
    // Calculating Total Marks
    
    let secondYear1stSemGainedMarks:UInt16 = UInt16(MEFAMarks)+UInt16(EEMMarks)+UInt16(TEPMarks)+UInt16(CSMarks)+UInt16(PEMarks)+UInt16(EM3Marks)+UInt16(EMLab2Marks)+UInt16(CSSimLabMarks)
    
    // Calculating Percentage
    
    let totalMarks1stSem:Float = 750
    
    let firstSemGainedMarks:Float = Float(secondYear1stSemGainedMarks)
    
    let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
    
    print("B-Tech 2nd Year 1st Sem Percentage = \(firstSemPercentage)")
    
    // finding out subject wise pass or fail
    
    var subPassMarks:UInt8 = 35
    var labPassMarks:UInt8 = 27
    
    var managerialEconomicsAndFinancialAnalysis:Bool = false
    var electricalAndElectronicsMeasurements:Bool = false
    var transmissionOfELectricalPower:Bool = false
    var controlSystems:Bool = false
    var powerElectronics:Bool = false
    var electricalMachines3:Bool = false
    var electricalMachinesLab2:Bool = false
    var controlSystemsAndSimulationLab:Bool = false
    
    if MEFAMarks >= subPassMarks
    {
        managerialEconomicsAndFinancialAnalysis = true
    } else {
        managerialEconomicsAndFinancialAnalysis = false
    }
    
    if EEMMarks >= subPassMarks
    {
        electricalAndElectronicsMeasurements = true
    } else {
        electricalAndElectronicsMeasurements = false
    }
    
    if TEPMarks >= subPassMarks
    {
        transmissionOfELectricalPower = true
    } else {
        transmissionOfELectricalPower = false
    }
    
    if CSMarks >= subPassMarks
    {
        controlSystems = true
    } else {
        controlSystems = false
    }
    
    if PEMarks >= subPassMarks
    {
        powerElectronics = true
    } else {
        powerElectronics = false
    }
    
    if EM3Marks >= subPassMarks
    {
        electricalMachines3 = true
    } else {
        electricalMachines3 = false
    }
    
    if EMLab2Marks >= labPassMarks
    {
        electricalMachinesLab2 = true
    } else {
        electricalMachinesLab2 = false
    }
    
    if  CSSimLabMarks >= labPassMarks
    {
        controlSystemsAndSimulationLab = true
    } else {
        controlSystemsAndSimulationLab = false
    }
    
    // Total 3rd Year 1st Sem pass or fail with grade
    
    var thirdYear1stSemResults:Bool = false
    
    if (managerialEconomicsAndFinancialAnalysis == true && electricalAndElectronicsMeasurements == true && transmissionOfELectricalPower == true && controlSystems == true && powerElectronics == true && electricalMachines3 == true && electricalMachinesLab2 == true && controlSystemsAndSimulationLab == true)
    {
        switch firstSemPercentage
        {
        case 90...100:
            print("Grade A")
        case 75..<90:
            print("Grade B")
        case 50..<75:
            print("Grade C")
        case 35..<50:
            print("Grade D")
        default:
            print("Grade E")
        }
        thirdYear1stSemResults = true
        print("B-Tech 3rd Year 1st Sem Passed")
    }
    else
    {
        thirdYear1stSemResults = false
        print("B-Tech 3rd Year 1st Sem Failed")
    }
    
    return thirdYear1stSemResults
    
}



func cal3rdYear2ndSemBtechResults(MSMarks:UInt8,PSDMarks:UInt8,PSAMarks:UInt8,MPMCMarks:UInt8,PSOCMarks:UInt8 = 74,LDICAMarks:UInt8 = 48,AECSLLabMarks:UInt8 = 61,EMLabMarks:UInt8 = 58) -> Bool
{
    // Calculating Total Marks
    
    let thirdYear2ndSemGainedMarks:UInt16 = UInt16(MSMarks)+UInt16(PSDMarks)+UInt16(PSAMarks)+UInt16(MPMCMarks)+UInt16(PSOCMarks)+UInt16(LDICAMarks)+UInt16(AECSLLabMarks)+UInt16(EMLabMarks)
    
    // Calculating Percentage
    
    let totalMarks2ndSem:Float = 750
    
    let secondSemGainedMarks:Float = Float(thirdYear2ndSemGainedMarks)
    
    let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
    
    print("B-Tech 3rd Year 1st Sem Percentage = \(secondSemPercentage)")
    
    // finding out subject wise pass or fail
    
    var subPassMarks:UInt8 = 35
    var labPassMarks:UInt8 = 27
    
    var managementScience:Bool = false
    var powerSemiconductorDrives:Bool = false
    var powerSystemAnalysis:Bool = false
    var microprocessorsAndMicrocontrollers:Bool = false
    var powerOperationsAndControl:Bool = false
    var linearAndDigitalICApplications:Bool = false
    var advancedEnglishCommunicationSkillsLab:Bool = false
    var electricalMeasurementsLab:Bool = false
    
    if MSMarks >= subPassMarks
    {
        managementScience = true
    } else {
        managementScience = false
    }
    
    if PSDMarks >= subPassMarks
    {
        powerSemiconductorDrives = true
    } else {
        powerSemiconductorDrives = false
    }
    
    if PSAMarks >= subPassMarks
    {
        powerSystemAnalysis = true
    } else {
        powerSystemAnalysis = false
    }
    
    if MPMCMarks >= subPassMarks
    {
        microprocessorsAndMicrocontrollers = true
    } else {
        microprocessorsAndMicrocontrollers = false
    }
    
    if PSOCMarks >= subPassMarks
    {
        powerOperationsAndControl = true
    } else {
        powerOperationsAndControl = false
    }
    
    if LDICAMarks >= subPassMarks
    {
        linearAndDigitalICApplications = true
    } else {
        linearAndDigitalICApplications = false
    }
    
    if AECSLLabMarks >= labPassMarks
    {
        advancedEnglishCommunicationSkillsLab = true
    } else {
        advancedEnglishCommunicationSkillsLab = false
    }
    
    if  EMLabMarks >= labPassMarks
    {
        electricalMeasurementsLab = true
    } else {
        electricalMeasurementsLab = false
    }
    
    // Total 2nd Year 2nd Sem pass or fail with grade
    
    var thirdYear2ndSemResults:Bool = false
    
    if (managementScience == true && powerSemiconductorDrives == true && powerSystemAnalysis == true && microprocessorsAndMicrocontrollers == true && powerOperationsAndControl == true && linearAndDigitalICApplications == true && electricalMeasurementsLab == true && advancedEnglishCommunicationSkillsLab == true)
    {
        switch secondSemPercentage
        {
        case 90...100:
            print("Grade A")
        case 75..<90:
            print("Grade B")
        case 50..<75:
            print("Grade C")
        case 35..<50:
            print("Grade D")
        default:
            print("Grade E")
        }
        thirdYear2ndSemResults = true
        print("B-Tech 3rd Year 2nd Sem Passed")
    }
    else
    {
        thirdYear2ndSemResults = false
        print("B-Tech 3rd Year 2nd Sem Failed")
    }
    
    return thirdYear2ndSemResults
    
}



func cal4thYear1stSemBtechResults(DEPMarks:UInt8,DSPMarks:UInt8,fundametalsofHVDCFactsDevicesMarks:UInt8,SGPMarks:UInt8 = 87,InstrumentationMarks:UInt8 = 89,OTMarks:UInt8 = 92,MPMCLabMarks:UInt8 = 65,PESimLabMarks:UInt8 = 69) -> Bool
{
    // Calculating Total Marks
    
    let fourthYear1stSemGainedMarks:UInt16 = UInt16(DEPMarks)+UInt16(DSPMarks)+UInt16(fundametalsofHVDCFactsDevicesMarks)+UInt16(SGPMarks)+UInt16(InstrumentationMarks)+UInt16(OTMarks)+UInt16(MPMCLabMarks)+UInt16(PESimLabMarks)
    
    // Calculating Percentage
    
    let totalMarks1stSem:Float = 750
    
    let firstSemGainedMarks:Float = Float(fourthYear1stSemGainedMarks)
    
    let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
    
    print("B-Tech 4th Year 1st Sem Percentage = \(firstSemPercentage)")
    
    // finding out subject wise pass or fail
    
    var subPassMarks:UInt8 = 35
    var labPassMarks:UInt8 = 27
    
    var distributionOfElectricalPower:Bool = false
    var digitalSignalProcessing:Bool = false
    var fundametalsOfHVDCFactsDevices:Bool = false
    var switchGearAndProtection:Bool = false
    var Instrumentation:Bool = false
    var optimizationTechniques:Bool = false
    var microprocessorsAndMicrocontrollersLab:Bool = false
    var powerElectronicsAndSimulationLab:Bool = false
    
    if DEPMarks >= subPassMarks
    {
        distributionOfElectricalPower = true
    } else {
        distributionOfElectricalPower = false
    }
    
    if DSPMarks >= subPassMarks
    {
        digitalSignalProcessing = true
    } else {
        digitalSignalProcessing = false
    }
    
    if fundametalsofHVDCFactsDevicesMarks >= subPassMarks
    {
        fundametalsOfHVDCFactsDevices = true
    } else {
        fundametalsOfHVDCFactsDevices = false
    }
    
    if SGPMarks >= subPassMarks
    {
        switchGearAndProtection = true
    } else {
        switchGearAndProtection = false
    }
    
    if InstrumentationMarks >= subPassMarks
    {
        Instrumentation = true
    } else {
        Instrumentation = false
    }
    
    if OTMarks >= subPassMarks
    {
        optimizationTechniques = true
    } else {
        optimizationTechniques = false
    }
    
    if MPMCLabMarks >= labPassMarks
    {
        microprocessorsAndMicrocontrollersLab = true
    } else {
        microprocessorsAndMicrocontrollersLab = false
    }
    
    if  PESimLabMarks >= labPassMarks
    {
        powerElectronicsAndSimulationLab = true
    } else {
        powerElectronicsAndSimulationLab = false
    }
    
    // Total 3rd Year 1st Sem pass or fail with grade
    
    var fourthYear1stSemResults:Bool = false
    
    if (distributionOfElectricalPower == true && digitalSignalProcessing == true && fundametalsOfHVDCFactsDevices == true && switchGearAndProtection == true && Instrumentation == true && optimizationTechniques == true && microprocessorsAndMicrocontrollersLab == true && powerElectronicsAndSimulationLab == true)
    {
        switch firstSemPercentage
        {
        case 90...100:
            print("Grade A")
        case 75..<90:
            print("Grade B")
        case 50..<75:
            print("Grade C")
        case 35..<50:
            print("Grade D")
        default:
            print("Grade E")
        }
        fourthYear1stSemResults = true
        print("B-Tech 4th Year 1st Sem Passed")
    }
    else
    {
        fourthYear1stSemResults = false
        print("B-Tech 4th Year 1st Sem Failed")
    }
    
    return fourthYear1stSemResults
    
}



func cal4thYear2ndSemBtechResults(PPQMarks:UInt8 = 60,UEEMarks:UInt8 = 67,MCTMarks:UInt8 = 53,EADSMMarks:UInt8 = 67,SeminarMarks:UInt8 = 45,ProjectWorkMarks:UInt16 = 300) -> Bool
{
    // Calculating Total Marks
    
    let fourthYear2ndSemGainedMarks:UInt16 = UInt16(PPQMarks)+UInt16(UEEMarks)+UInt16(MCTMarks)+UInt16(EADSMMarks)+UInt16(SeminarMarks)+ProjectWorkMarks
    
    // Calculating Percentage
    
    let totalMarks2ndSem:Float = 750
    
    let secondSemGainedMarks:Float = Float(fourthYear2ndSemGainedMarks)
    
    let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
    
    print("B-Tech 4th Year 1st Sem Percentage = \(secondSemPercentage)")
    
    // finding out subject wise pass or fail
    
    var subPassMarks:UInt8 = 35
    var projectPassMarks:UInt16 = 90
    var semibarPassMarks:UInt8 = 15
    
    var principlesofPowerQuality:Bool = false
    var utilizationofElectricalEnergy:Bool = false
    var modernControlTheory:Bool = false
    var EnergyAuditingandDemandSideManagement:Bool = false
    var seminar:Bool = false
    var projectWork:Bool = false
   
    if PPQMarks >= subPassMarks
    {
        principlesofPowerQuality = true
    } else {
        principlesofPowerQuality = false
    }
    
    if UEEMarks >= subPassMarks
    {
        utilizationofElectricalEnergy = true
    } else {
        utilizationofElectricalEnergy = false
    }
    
    if MCTMarks >= subPassMarks
    {
        modernControlTheory = true
    } else {
        modernControlTheory = false
    }
    
    if EADSMMarks >= subPassMarks
    {
        EnergyAuditingandDemandSideManagement = true
    } else {
        EnergyAuditingandDemandSideManagement = false
    }
    
    if SeminarMarks >= subPassMarks
    {
        seminar = true
    } else {
        seminar = false
    }
    
    if ProjectWorkMarks >= subPassMarks
    {
        projectWork = true
    } else {
        projectWork = false
    }
    
    
    // Total 2nd Year 2nd Sem pass or fail with grade
    
    var fourthYear2ndSemResults:Bool = false
    
    if (principlesofPowerQuality == true && utilizationofElectricalEnergy == true && modernControlTheory == true && EnergyAuditingandDemandSideManagement == true && seminar == true && projectWork == true)
    {
        switch secondSemPercentage
        {
        case 90...100:
            print("Grade A")
        case 75..<90:
            print("Grade B")
        case 50..<75:
            print("Grade C")
        case 35..<50:
            print("Grade D")
        default:
            print("Grade E")
        }
        fourthYear2ndSemResults = true
        print("B-Tech 4th Year 2nd Sem Passed")
    }
    else
    {
        fourthYear2ndSemResults = false
        print("B-Tech 4th Year 2nd Sem Failed")
    }
    
    return fourthYear2ndSemResults
    
}
