//
//  ViewController.swift
//  AutoLayouts
//
//  Created by Vadde Narendra on 10/29/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameLbl: UILabel!
    @IBOutlet weak var lastNameLbl: UILabel!
    @IBOutlet weak var DOBLbl: UILabel!
    @IBOutlet weak var ageLbl: UILabel!
    @IBOutlet weak var ageCalculatingLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var mobileNoLbl: UILabel!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var stateNameLbl: UILabel!
    @IBOutlet weak var countryNameLbl: UILabel!
    
    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var DOBTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var mobileNoTF: UITextField!
    @IBOutlet weak var addressTV: UITextView!
    @IBOutlet weak var stateNameTF: UITextField!
    @IBOutlet weak var countryNameTF: UITextField!
    
    var alertControl = UIAlertController()
    var actionControl = UIAlertAction()
    var datePick = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    @IBAction func submitBtnTapped(_ sender: Any)
    {
        if ((firstNameTF.text?.isEmpty)! ||
            (lastNameTF.text?.isEmpty)! ||
            (DOBTF.text?.isEmpty)! ||
            (mobileNoTF.text?.isEmpty)! ||
            (emailTF.text?.isEmpty)! ||
            (addressTV.text?.isEmpty)! ||
            (stateNameTF.text?.isEmpty)! ||
            (countryNameTF.text?.isEmpty)!)
        {
            alertMsgs(titleName: "WARNING", messageDetails: "Please enter valid details")
        }
        else
        {
            alertMsgs(titleName: "CONGRATULATIONS", messageDetails: "successfully created your account")
        }
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        var returnValue:Bool = true
        
        if(textField == firstNameTF)
        {
            returnValue = true
        }
        else if(textField == lastNameTF)
        {
            if((firstNameTF.text?.count)! > 2)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
            
        }
        else if(textField == DOBTF)
        {
            if((lastNameTF.text?.count)! > 2)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
            
        }
        else if(textField == emailTF)
        {
            if((DOBTF.text?.isEmpty)!)
            {
                returnValue = false
            }
            else
            {
                returnValue = true
            }
            
        }
        else if(textField == mobileNoTF)
        {
            if((emailTF.text?.count)! > 2)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
            
        }
        else if(textField == stateNameTF)
        {
            if((addressTV.text?.count)! > 2)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
            
        }
        else if(textField == countryNameTF)
        {
            if((stateNameTF.text?.count)! > 2)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
            
        }
         return returnValue
    } // return NO to disallow editing.
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.textColor = UIColor.red
    }// became first responder
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if(textField ==  firstNameTF ||
            textField == lastNameTF ||
            textField == stateNameTF ||
            textField == countryNameTF)
        {
            if(isValidName(nameStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                textField.textColor = .red
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter only alphabets and enter minimum 2 letters")
            }
            
        }
        if(textField == emailTF)
        {
            if(isValidEmail(emailStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter email and it's format like xxxx@xxxx.xxx")
                textField.textColor = .red
            }
            
        }
        if(textField == mobileNoTF){
            if(isValidMobileNo(mobileNoStr: textField.text!))
            {
                textField.textColor = .black
            }
            else
            {
                alertMsgs(titleName: "WARNING", messageDetails: "Please enter Mobile number in numarics and it's format like +9XXXXXXXXXXX")
                textField.textColor = .red
            }
            
        }
        return true
    }// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.textColor = UIColor.black
    }// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }// called when clear button pressed. return NO to ignore (no notifications)
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return true
    }// called when 'return' key pressed. return NO to ignore.
    
    // function creating for email validation
    
    func isValidEmail(emailStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    // function creating for name validation
    
    func isValidName(nameStr:String) -> Bool {
        
        let nameRegEx = "[A-Za-z ]{2,50}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        return emailPred.evaluate(with: nameStr)
    }
    
    // function creating for mobile number validation
    
    func isValidMobileNo(mobileNoStr : String) -> Bool {
        
        let mobileNoRegEx = "^((\\+)|(0))[0-9]{6,14}$"
        
        let mobileNoPred = NSPredicate(format: "SELF MATCHES %@",mobileNoRegEx)
        return mobileNoPred.evaluate(with: mobileNoStr)
    }
    
    // alert msg function
    
    func alertMsgs(titleName:String, messageDetails:String)
    {
        alertControl = UIAlertController(title: titleName, message: messageDetails, preferredStyle: UIAlertController.Style.alert)
        self.present(alertControl, animated: true, completion: nil)
        actionControl = UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        alertControl.addAction(actionControl)
        
    }
    
    // return NO to disallow editing.
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool
    {
        var returnValue:Bool = false
        
        if(textView == addressTV){
            if(mobileNoTF.text!.count >= 6){
                returnValue = true
            }else{
                returnValue = false
            }
        }
        return returnValue
    }
    
    // became first responder
    
    func textViewDidBeginEditing(_ textView: UITextView)
    {
        textView.textColor = UIColor.red
    }
    
    // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    
    func textViewDidEndEditing(_ textView: UITextView)
    {
        textView.textColor = UIColor.black
    }
    
    // function for event handle of date picker
    
    @objc func handleDatePicker(datePick:UIDatePicker)
    {
        ageCalculatingLbl.removeFromSuperview()
        
        let pickerDateFormatter = DateFormatter()
        pickerDateFormatter.dateFormat = "dd-MM-YYYY"
        DOBTF.text = pickerDateFormatter.string(from: datePick.date)
        
        DOBTF.resignFirstResponder()
        
        let dateOfBirth = pickerDateFormatter.date(from: DOBTF.text!)
        
        let calender = Calendar.current
        
        let dateComponent = calender.dateComponents([.year, .month, .day], from:
            dateOfBirth!, to: Date())
        
        
        ageCalculatingLbl.text = "\(dateComponent.year!) Year \(dateComponent.month!) Month \(dateComponent.day ?? 0) Day"
        ageCalculatingLbl.textColor = UIColor.black
        ageCalculatingLbl.textAlignment = .center
    }
    
    // function creating for minimum & maximum age setting and event hamdler calling
    
    func showDate()
    {
        datePick.datePickerMode = UIDatePicker.Mode.date
        
        let minDateCalendar = Calendar.current
        
        var minDateComponent = minDateCalendar.dateComponents([.day,.month,.year], from: datePick.date)
        minDateComponent.day = 01
        minDateComponent.month = 01
        minDateComponent.year = 1970
        
        datePick.minimumDate = minDateCalendar.date(from: minDateComponent)
        
        let maxDate = Date()
        
        let maxDateCalender = Calendar.current
        
        var maxDateComponent = maxDateCalender.dateComponents([.day,.month,.year], from: Date())
        maxDateComponent.day = maxDateCalender.component(.day, from: maxDate)
        maxDateComponent.month = maxDateCalender.component(.month, from: maxDate)
        maxDateComponent.year = maxDateCalender.component(.year, from: maxDate)
        
        datePick.maximumDate = maxDateCalender.date(from: maxDateComponent)
        
        datePick.addTarget(self, action: #selector(handleDatePicker(datePick:)), for: UIControl.Event.valueChanged)
        
        DOBTF.inputView = datePick
    }
    
}
