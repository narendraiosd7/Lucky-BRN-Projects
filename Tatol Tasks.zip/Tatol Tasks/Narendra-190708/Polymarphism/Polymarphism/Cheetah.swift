//
//  Cheetah.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Cheetah: Cat {

    var speed:String?
    
    override func dailyActivities(){
        
        print("Cheetah belongs to \(family!) family")
        print("Cheetah sleeps approximately \(sleepingHours!)")
        print("Cheetah \(eatingHabits!)")
        print("Cheetah \(sleepingHabits!)")
        print("Cheetah hunts \(huntingHabits!)")
        print("Cheetah runs \(speed)")
        
    }
    
}
