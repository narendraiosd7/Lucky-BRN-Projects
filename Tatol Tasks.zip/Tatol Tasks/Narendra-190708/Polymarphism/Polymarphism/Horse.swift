//
//  Horse.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Horse: Zebra {
    
    var speed:String?
    
    override func activities() {
        
        print("Horse \(eatingHabit!)")
        print("Horse is used to \(uses!) purpose")
        print("Horse running speed is \(speed!)")
        
    }
    
}
