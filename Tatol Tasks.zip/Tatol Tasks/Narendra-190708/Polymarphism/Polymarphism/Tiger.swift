//
//  Tiger.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Tiger: Cheetah {

    var find:String?
    
    override func dailyActivities(){
        
        print("Tiger belongs to \(family!) family")
        print("Tiger sleeps approximately \(sleepingHours!)")
        print("Tiger \(eatingHabits!)")
        print("Tiger \(sleepingHabits!)")
        print("Tiger hunts \(huntingHabits!)")
        print("Tiger found in only \(find!)")
    }
}
