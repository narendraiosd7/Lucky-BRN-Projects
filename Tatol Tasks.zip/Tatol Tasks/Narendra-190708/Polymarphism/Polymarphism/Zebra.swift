//
//  Zebra.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Zebra: Donkey {

    var staying:String?
    
    override func activities() {
        
        print("Zebra \(eatingHabit!)")
        print("Zebra staying in \(staying!)")
    }
}
