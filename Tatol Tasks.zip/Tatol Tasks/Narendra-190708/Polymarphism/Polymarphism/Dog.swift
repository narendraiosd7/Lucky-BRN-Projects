//
//  Dog.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Dog: NSObject {

    var eatingHabit:String?
    
    func activities() {
        
        print("Dog \(eatingHabit!)")
        
    }
}
