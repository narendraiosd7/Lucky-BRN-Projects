//
//  Pigeon.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Pigeon: NSObject {

    var noOfWings:String = "Two"
    var noOfLegs:String = "Two"
    
    func pigeonDescription(){
        
        print("Number of wings = \(noOfWings)")
        print("Number of legs = \(noOfLegs)")
    }
}
