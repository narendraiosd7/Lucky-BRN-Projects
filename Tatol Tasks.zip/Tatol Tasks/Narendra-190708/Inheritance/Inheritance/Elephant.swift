//
//  Elephant.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Elephant: Horse {

    var noOfTails:UInt8 = 1
    
    func elephantDescription(){
        
        print("Number of legs = \(noOfLegs)")
        print("Number of tails = \(noOfTails)")
    }
    
}
