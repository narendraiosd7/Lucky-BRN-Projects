//
//  Crocodile.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Crocodile: Snake {
    
    let noOfLegs:String = "Four"
    
    func crocodileDescription(){
        print("It's skin type is \(skinType)")
        print("It can \(eatingType)")
        print("It can lives on \(lives)")
        print("Number of legs of Crocodile = \(noOfLegs)")
    }
}
