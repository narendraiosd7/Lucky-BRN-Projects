//
//  Snake.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Snake: NSObject {

    let skinType:String = "Scaly Skins"
    
    let eatingType:String = "Swallow"
    
    let lives:String = "Earth and in Water"
    
    func snakeDescription(){
        
        print("It's skin type is \(skinType)")
        
        print("It can \(eatingType)")
        
        print("It can lives on \(lives)")
    }
    
}
