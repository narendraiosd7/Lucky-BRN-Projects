//
//  Tiger.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Tiger: Lion {

    var familyType:String = "Cat"
    
    func tigerDescription(){
        
        print("Number of tails = \(numberOfTails)")
        print("Number of eyes = \(numberOfeyes)")
        print("Number of legs = \(numberOfLegs)")
        print("It belongs to = \(familyType) family")
    }
}
