//
//  ViewController.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let kingCobra = Snake()
        
        kingCobra.snakeDescription()
        
        let crocodile = Crocodile()
        
        crocodile.crocodileDescription()
        
        let redAnt = Ant()
        
        redAnt.antDescription()
        
        let pigeon = Pigeon()
        
        pigeon.pigeonDescription()
        
        let eagle = Eagle()
        
        eagle.eagleDescription()
        
        let peacock = Peacock()
        
        peacock.peacockDescription()
        
        let lion = Lion()
        
        lion.lionDescription()
        
        let tiger = Tiger()
        
        tiger.tigerDescription()
        
        let cheetah = Cheetah()
        
        cheetah.cheetahDesciption()
        
        let horse = Horse()
        
        horse.horseDescription()
        
        let elephant = Elephant()
        
        elephant.elephantDescription()
        
        let giraffe = Giraffe()
        
        giraffe.giraffeDescription()
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

