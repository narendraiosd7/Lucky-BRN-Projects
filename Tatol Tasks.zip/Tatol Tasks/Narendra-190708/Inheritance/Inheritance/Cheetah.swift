//
//  Cheetah.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Cheetah: Tiger {

    var runs:String = "Very speed"
    
    func cheetahDesciption(){
        
        print("Number of tails = \(numberOfEyes)")
        print("Number of legs = \(numberOfLegs)")
        print("It belongs to = \(familyType) family")
        print("It can run \(runs)")
        
        super
    }
    
}
