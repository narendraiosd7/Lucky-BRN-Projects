//
//  File.swift
//  Structs_13.8.19
//
//  Created by Vadde Narendra on 13/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

/*import Foundation

struct InterCalculations {
    init(san1stYearMarks:UInt8,eng1stYearMarks:UInt8,mathsA1stYearMarks:UInt8,mathsB1stYearMarks:UInt8,physics1stYearMarks:UInt8,chemistry1stYearMarks:UInt8,san2ndYearMarks:UInt8,eng2ndYearMarks:UInt8,mathsA2ndYearMarks:UInt8,mathsB2ndYearMarks:UInt8,physics2ndYearMarks:UInt8,chemistry2ndYearMarks:UInt8,physicsLab:UInt8,chemistryLab:UInt8) {
        
        // 1st Year Inter pass marks & Total marks
        
        let subPassMarks1:UInt8 = 35
        let subPassMarks2:UInt8 = 24
        let subPassMarks3:UInt8 = 18
        
        // Inter 1st Year Percentage calculatations
        
        let total1stYearMarks:Float = 470
        
        var interFirstYearResults:Bool = false
        
        // Inters 1st Year Total Marks calculations
        
        let firsYearGainedMarks:UInt16 = UInt16(san1stYearMarks)+UInt16(eng1stYearMarks)+UInt16(mathsA1stYearMarks)+UInt16(physics1stYearMarks)+UInt16(chemistry1stYearMarks)+UInt16(mathsB1stYearMarks)
        
        print("First Year Marks = \(firsYearGainedMarks)")
        
        // Inter 1st Year Marks converted in Float & Calculating Percentage
        
        let firsYearMarks:Float = Float(firsYearGainedMarks)
        
        // Inter 1st Year Percentage calculations
        
        let firsYearPercentage:Float = (firsYearMarks/total1stYearMarks)*100
        
        print("1st Year Percentage = \(firsYearPercentage)")
        
        // Passed or failed in Inter subject-wise is given below
        
        var sanskrit:Bool = false
        var english:Bool = false
        var mathsA:Bool = false
        var mathsB:Bool = false
        var physics:Bool = false
        var chemistry:Bool = false
        
        
        if san1stYearMarks >= subPassMarks1 {
            sanskrit = true
        } else {
            sanskrit = false
        }
        
        if eng1stYearMarks >= subPassMarks1 {
            english = true
        } else {
            english = false
        }
        
        if mathsA1stYearMarks >= subPassMarks2 {
            mathsA = true
        } else {
            mathsA = false
        }
        
        if mathsB1stYearMarks >= subPassMarks2 {
            mathsB = true
        } else {
            mathsB = false
        }
        
        if physics1stYearMarks >= subPassMarks3 {
            physics = true
        } else {
            physics = false
        }
        
        if chemistry1stYearMarks >= subPassMarks3 {
            chemistry = true
        } else {
            chemistry = false
        }
        
        // Passed or failed in Inter is given below
        
        if (sanskrit == true && english == true && mathsA == true && mathsB == true && physics == true && chemistry == true){
            switch firsYearPercentage{
            case 90...100:
                print("Grade = A")
            case 75..<90:
                print("Grade = B")
            case 50..<75:
                print("Grade = C")
            case 35..<50:
                print("Grade = D")
            default:
                print("Grade = E")}
            interFirstYearResults = true
            print("Inter 1st Year PASSED")
        } else {
            interFirstYearResults = false
            print("Inter 1st Year FAILED")
        }
    
        // Inter 2nd Year pass marks
        
        let labPassMarks:UInt8 = 18
        
        // Inter 2nd Year Total Marks are available in Float below
        
        let total2ndYearMarks:Float = 530
        
        var interSecondYearResults:Bool = false
        
        // Inters 2nd Year Total Marks coding is available below
        
        let secondYearGainedMarks:UInt16 = UInt16(san2ndYearMarks)+UInt16(eng2ndYearMarks)+UInt16(mathsA2ndYearMarks)+UInt16(mathsB2ndYearMarks)+UInt16(physics2ndYearMarks)+UInt16(chemistry2ndYearMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
        
        print("2nd Year Marks = \(secondYearGainedMarks)")
        
        // Inter 2nd Year Marks converted in Float
        
        let secondYearMarks:Float = Float(secondYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let secondYearPercentage:Float = (secondYearMarks/total2ndYearMarks)*100
        
        print("2nd Year Percentage = \(secondYearPercentage)")
        
        // Passed or failed in Inter 2nd Year is given below
        
        var sanskritMarks:Bool = false
        var englishMarks:Bool = false
        var mathsAMarks:Bool = false
        var mathsBMarks:Bool = false
        var physicsMarks:Bool = false
        var chemistryMarks:Bool = false
        var physicsPracticals:Bool = false
        var chemistryPracticals:Bool = false
        
        if san2ndYearMarks >= subPassMarks1 {
            sanskritMarks = true
        } else {
            sanskritMarks = false
        }
        
        if eng2ndYearMarks >= subPassMarks1 {
            englishMarks = true
        } else {
            englishMarks = false
        }
        
        if mathsA2ndYearMarks >= subPassMarks1 {
            mathsAMarks = true
        } else {
            mathsAMarks = false
        }
        
        if mathsB2ndYearMarks >= subPassMarks1 {
            mathsBMarks = true
        } else {
            mathsBMarks = false
        }
        
        if physics2ndYearMarks >= subPassMarks2 {
            physicsMarks = true
        } else {
            physicsMarks = false
        }
        
        if chemistry2ndYearMarks >= subPassMarks2 {
            chemistryMarks = true
        } else {
            chemistryMarks = false
        }
        
        if physicsLab >= labPassMarks {
            physicsPracticals = true
        } else {
            physicsPracticals = false
        }
        
        if chemistryLab >= labPassMarks {
            chemistryPracticals = true
        } else {
            chemistryPracticals = false
        }
        
        // Passed or failed in Inter 2nd Year is given below
        
        if (sanskritMarks == true && englishMarks == true && mathsAMarks == true && mathsBMarks == true && physicsMarks == true && chemistryMarks == true && physicsPracticals == true && chemistryPracticals == true){
            switch secondYearPercentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            interSecondYearResults = true
            print("Inter 2nd Year PASSED")
        } else {
            interSecondYearResults = false
            print("Inter 2nd Year FAILED")
        }
        
        // Inter total marks
        
        let totalInterGainedMarks:UInt16 = firsYearGainedMarks + secondYearGainedMarks
        
        print("Total Marks = \(totalInterGainedMarks)")
        
        // Inter percentage
        
        let totalMarks:Float = 1000
        
        let percentage:Float = (Float(totalInterGainedMarks)/totalMarks)*100
        
        print("Inter Percentage = \(percentage)")
        
        if (interFirstYearResults == true && interSecondYearResults == true){
            
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Inter Passed")
        }
            else{
            print("Inter Failed")
            }
        }
    }
*/
