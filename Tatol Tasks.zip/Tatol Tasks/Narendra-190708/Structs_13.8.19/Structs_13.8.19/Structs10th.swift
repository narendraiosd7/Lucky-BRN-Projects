//
//  Structs10th.swift
//  Structs_13.8.19
//
//  Created by Vadde Narendra on 13/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import Foundation

struct Tenthcalculations{
    
    init(telMarks:UInt8,engMarks:UInt8,hindiMarks:UInt8,mathsMarks:UInt8,sciMarks:UInt8,socMarks:UInt8) {
    
        // Considering pass marks & total marks
        
        let passMarks:UInt8 = 35
        let totalMarks:Float = 600
        
        // calculatng total marks & printing
        
        let gainedMarks:UInt16 = UInt16(telMarks)+UInt16(engMarks)+UInt16(hindiMarks)+UInt16(mathsMarks)+UInt16(sciMarks)+UInt16(socMarks)
        
        print("Total Marks = \(gainedMarks)")
        
        // calculating percentage & printing
        
        let percentage:Float = (Float(gainedMarks)/totalMarks)*100
        
        print("Percentage = \(percentage)")
        
        // calculating grade with pass or fail overall tenth
        
        if (telMarks >= passMarks && engMarks >= passMarks && hindiMarks >= passMarks && mathsMarks >= passMarks && sciMarks >= passMarks && socMarks >= passMarks)
        {
            switch percentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Tenth Passed")
        }
        else
        {
            print("Tenth Failed")
        }
    }
}
