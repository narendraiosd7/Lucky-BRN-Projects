//
//  proparty observers.swift
//  Protocols,Extensions, Property Observers, Setters and Getters_22.08.19
//
//  Created by Vadde Narendra on 22/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Property_observers: NSObject {
    
    var passMarks:UInt8 = 35
}
