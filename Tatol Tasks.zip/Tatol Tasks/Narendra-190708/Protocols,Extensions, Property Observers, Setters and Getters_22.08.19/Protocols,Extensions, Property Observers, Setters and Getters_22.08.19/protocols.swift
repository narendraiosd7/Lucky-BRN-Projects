//
//  protocols.swift
//  Protocols,Extensions, Property Observers, Setters and Getters_22.08.19
//
//  Created by Vadde Narendra on 22/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import Foundation

@ objc protocol TenthClass {
    
    var passMarks:UInt8 {get}
    var engMarks:UInt8 {get set}
    var telMarks:UInt8 {get set}
    var hindiMarks:UInt8 {get set}
    var mathsMarks:UInt8 {get set}
    var sciMarks:UInt8 {get set}
    var socMarks:UInt8 {get set}
    
    @objc optional var totalMarks:UInt16 {get set}
    
    
    func tenthCalculations()
}
