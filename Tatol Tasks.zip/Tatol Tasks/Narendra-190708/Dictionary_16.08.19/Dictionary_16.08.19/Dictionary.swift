//
//  Dictionary.swift
//  Dictionary_16.08.19
//
//  Created by Vadde Narendra on 16/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import Foundation

struct District {
    
    var district = [String:String]()
    
    init (districtName:String,headquaters:String){
        
        district["distrcit"] = districtName
        district["headquaters"] = headquaters
        
    }
}
