//
//  ViewController.swift
//  URLSessions_28.08.19
//
//  Created by Vadde Narendra on 8/30/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var URLReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //method - 1
        
        getIndiaDetails(type:"states",quantity:10)
        
        getActorsandQutes(type:"quotes",quantity:5)
        getValidateLogin(mail:"narendraiosd@gmail.com",password:"nanda143",name:"verifyLogin")
        
        getUserAttendance(name:"getUserAttendance",value:"NoValue")
        
        
        //method -2
        
        getIndiaDetails(url: "https://brninfotech.com/tws/IndiaDetails.php?type=states&quantity=100")
        
        getActorsandQutes(url: "https://brninfotech.com/tws/Quotes.php?", sendingData: "type=actors&quantity=10")
        
        getValidateLogin(url:"https://www.brninfotech.com/pulse/modules/admin/ValidateLogin.php?",sendingData:"registeredEmail=narendraiosd@gmail.com&registeredPassword=nanda143&funcName=verifyLogin")
        
        getUserAttendance(url:"https://www.brninfotech.com/pulse/modules/admin/DashboardSnippets.php?",sendingData:"funcName=getUserAttendance&studentIDByAdmin=NoValue")
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //for getting India's Details
    
    func getIndiaDetails(type:String,quantity:Int){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/IndiaDetails.php?type=\(type)&quantity=\(quantity)")!)
        
        URLReqObj.httpMethod = "GET"
        
        //                var dataToSend = "type=\(type)&quatity=\(quantity)"
        //
        //                URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    //for getting actors Details
    
    func getActorsandQutes(type:String,quantity:Int){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/Quotes.php?")!)
        
        URLReqObj.httpMethod = "POST"
        
        var dataToSend = "type=\(type)&quantity=\(quantity)"
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    //for getting Login Details
    
    func getValidateLogin(mail:String,password:String,name:String){
        
        
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/ValidateLogin.php?")!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = "registeredEmail=\(mail)&registeredPassword=\(password)&funcName=\(name)"
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        }
        dataTaskObj.resume()
    }
    
    //for getting User's Attendance Details
    
    func getUserAttendance(name:String,value:String){
        
        
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/DashboardSnippets.php?")!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = "funcName=\(name)&studentIDByAdmin=\(value)"
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        }
        dataTaskObj.resume()
    }
    
    // "********************************************************" //
    
    //for getting India's Details
    
    func getIndiaDetails(url:String){
        
        URLReqObj = URLRequest(url: URL(string: url)!)
        
        URLReqObj.httpMethod = "Get"
        
        //        var dataToSend = "type=state&quatity"
        //
        //        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    //for getting actors Details
    
    func getActorsandQutes(url:String,sendingData:String){
        
        URLReqObj = URLRequest(url: URL(string: url)!)
        
        URLReqObj.httpMethod = "POST"
        
        var dataToSend = sendingData
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    //for getting Login Details
    
    func getValidateLogin(url:String,sendingData:String){
        
        
        URLReqObj = URLRequest(url: URL(string: url)!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = sendingData
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        }
        dataTaskObj.resume()
    }
    
    
    //for getting User's Attendance Details
    
    func getUserAttendance(url:String,sendingData:String){
        
        
        URLReqObj = URLRequest(url: URL(string: url)!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = sendingData
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(convertedData)
            } catch {
                print("the error is \(String(describing: Error))")
            }
        }
        dataTaskObj.resume()
    }
    
}
