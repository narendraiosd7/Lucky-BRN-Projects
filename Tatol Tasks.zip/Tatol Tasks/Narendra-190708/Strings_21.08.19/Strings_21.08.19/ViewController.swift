//
//  ViewController.swift
//  Strings_21.08.19
//
//  Created by Vadde Narendra on 21/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let todayNews:NSString = "Modi govt using ED, CBI to character assassinate Chidambaram, says Rahul Gandhi"
        
        print(todayNews)
        
        let updatedNews:NSString = todayNews.appending("The ED has issued a lookout notice against P Chidambaram after failing to locate the senior Congress leader.") as NSString
        
        print(updatedNews)
        
        print(updatedNews.length) // length finding
        
        print(updatedNews.lowercased) // doing lowercased
        
        print(updatedNews.capitalized) // doing capitalized
        
        print(updatedNews.uppercased) // doing uppercased
        
        print(updatedNews.components(separatedBy: " ")) // seperating
        
        print(updatedNews.substring(to: 5)) // taking wanted string sing substring
        
        print(updatedNews.substring(with: NSRange(location: 25, length: 25))) // taking wanted string sing substring
        
        print(updatedNews.substring(from: 24)) // taking wanted string sing substring
        
        print(updatedNews.contains("lookout")) //checking string wheither available or not
        
        print(updatedNews.replacingOccurrences(of: "a", with: "@")) // replacing letters
        
        // creating mutuable string
        
        let newsAboutChidambaram:NSMutableString = "Modi govt using ED, CBI to character assassinate Chidambaram, says Rahul Gandhi"
        
        newsAboutChidambaram.append("The ED has issued a lookout notice against P Chidambaram after failing to locate the senior Congress leader. All eyes are now on CJI after the Supreme Court said it couldn’t pass an order on Chidambaram immediately")
        
        print(newsAboutChidambaram)
        
       newsAboutChidambaram.deleteCharacters(in: NSRange(location: 0, length: 10)) // deleting characters
        
        print(newsAboutChidambaram)
        
        newsAboutChidambaram.insert("Modi govt ", at: 0) // inserting a string
        
        print(newsAboutChidambaram)
        
        newsAboutChidambaram.replaceCharacters(in: NSRange(location: 0, length: 99), with: "@") //replacing some characters with @
        
        print(newsAboutChidambaram)
        
        
        var news = "Modi govt using ED, CBI to character assassinate Chidambaram, says Rahul Gandhi"
        
        if let i = news.firstIndex(of: "M")
        {
        news.remove(at : i)
        }
        
        print(news)
        
        print(news.removeFirst())
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

